# Offline environmental rebuild

From this package folder, run `node tools/environment-build-v023.cjs`. Node standard library only; no network, API keys, package installation or new measurements. Included source files: CC BY WorldCover clip+georeference, hourly CAMS/Open-Meteo2021 JSON and acquisition manifest. Existing OSM-derived baseline results and display routes are in data/.

The command rebuilds data/environment-data.js and writes derived JSON/CSV under data/processed/environment. Generation timestamp will differ; analytical content and source hashes remain reproducible. It does not recreate the original OSM routing graph. See ENVIRONMENT-METHODS.md and DATA-LICENSE.md for exact indicators, formulas, licences and limitations.
