# SportSpace — dostupnost i okruženje za aktivnost

**doc. dr. Semir Poturak · prof. dr. Amra Tuzović**  
University of Travnik, Faculty of Technical Sciences

Lokalni v0.24 povezuje modelovane puteve, satelitsku vegetaciju i vodu sa istorijskim regionalnim vazduhom. Tri modela dostupnosti, Pareto poređenje i analiza vremenskih/prostornih pragova koriste postojeće sekundarne podatke; nova merenja nisu preduslov ovog rada.

- **Slojevi i jezici:** BS (ijekavica), EN i TR; četiri smislene kombinacije, prikaz izvornih satelitskih klasa, vegetacijski gradijent i lista OSM zelenih površina. [Metod prikaza i provjere](VISUALIZATION_METHODS_24.md).
- **Zelenilo i voda:** stvarno obrađen WorldCover2021 izvod; 100/300/500m oko12mesta i vegetacija uz228putanja.
- **Vazduh:** CAMS/Open-Meteo2021, 8760sati za PM2.5/PM10/NO2/O3; jedna regionalna ćelija, mesečni i satni profili.
- **Modeli:** najbliže mesto, kumulativne mogućnosti, eksponencijalni potencijal; referentni izvori i jednačine su i na sajtu.
- **2D/3D:** raster, ilustrativni simboli vegetacionih ćelija, rotacija, nagib, pan, zoom, klik za detalje.

[Metod, izvori, formule i licence](ENVIRONMENT_ANALYSIS_23.md) · [Ponovljivost](REPRODUCIBILITY.md) · [Autori](AUTHORS.md) · [Istraživački plan](paper/RESEARCH_PLAN.md).

Status: lokalna verzija; javni [GitHub](https://github.com/3esign/sportspace-pilot) / Pages još prikazuje ranije izdanje. Nije izvršena objava. Okruženje2021 i mreža2026 su različiti vremenski preseci; nema zdravstvenog skora ili tvrdnje o izmerenoj upotrebi prostora.

<details><summary>Prethodni razvoj i istorijski checkpoint-i</summary>

# SportSpace — grad, kretanje i mogućnosti za aktivnost

**doc. dr. Semir Poturak · prof. dr. Amra Tuzović**  
University of Travnik, Faculty of Technical Sciences · [fts.edu.ba](https://fts.edu.ba/)

SportSpace je istraživački 2D/3D alat za povezivanje prostora za aktivnost, modelovanog vremena puta i odluka o dostupnosti. Lokalni v0.22 dodaje dva upotrebljiva toka: izbor mesta unutar vremenskog praga i poređenje scenarija bez jednog odredišta. Rezultati predstavljaju model na fiksnom snimku, ne trenutno stanje grada.

| Korisnik | Pitanje | Šta sada radi |
|---|---|---|
| Građanin | Šta mogu da dosegnem za 15 minuta? | Izbor aktivnosti i probnog polazišta, lista mesta, putanja i izvori |
| Planer / upravljač | Šta se menja kada mesto nije dostupno? | Pre/posle za 20 sintetičkih tačaka, gubitak opcija, CSV sa parametrima i hashom izvora |
| Istraživač | Kako je rezultat dobijen? | Neizmenjen method_run_002, ulazni podaci, ograničenja i ponovljive provere |

**Status:** v0.22 lokalno; javni pilot je raniji v0.19. Nema objavljenog rada, DOI-ja ili dokazane zdravstvene efikasnosti. Nema terenski validirane navigacije ili senzorskog toka uživo.

- [Korisnost, akteri i razvoj podataka](PRODUCT_AND_STAKEHOLDERS_22.md)
- [Ponovljivost i provere](REPRODUCIBILITY.md)
- [Autori](AUTHORS.md) · [citiranje softvera](CITATION.cff)
- [Plan rada i granice tvrdnji](paper/RESEARCH_PLAN.md)
- [Licence i odluke o objavi](PUBLICATION_MANIFEST_18.md)

Repozitorijum u celini je radni istraživački dosije. Za buduću javnu objavu koristi se pregledan spisak fajlova; privatni izvodi, kontakti i materijal trećih strana ne objavljuju se automatski.

<details><summary>Istorija razvoja i raniji checkpoint-i (istorijski statusi)</summary>

# SportSpace

Istraživačka priprema o sportu, zdravlju, telu, ponašanju, gradskom prostoru i javnim podacima za mogući naučni rad i GitHub pilot. Lokalni kandidati: Ilidža/Stup, Sarajevo i Travnik. Radni naziv projekta, bez zaključane teme.

## Status

- **Lokalni pilot v0.21:** [implementacija 2D/3D interfejsa](IMPLEMENTACIJA_21.md), [dizajnerski smer](UI_DIRECTION_21.md), [browser QA](review/v021/qa.json). Stvarna OSM podloga, WebGL prostor, animacija putanje, izbor aktivnosti i korisno poređenje. Pripremljen odvojen `release/github-pages-v021`; javni GitHub Pages ostaje v0.19 dok se zasebno ne objavi.

- Analiza v0.20 (bez izmene javnog v0.19): [smisao projekta, rezultati, UI/UX i predlog razvoja](ANALIZA_SMISLA_I_UX_20.md). Aktuelni javni sajt ostaje v0.19; novi pregled pokazuje jaz između metodskog pilota i korisničkog alata za grad i fizičku aktivnost.

- Javni repo: https://github.com/3esign/sportspace-pilot

- Aktuelno v0.19: [javni E01 pilot paket](site/README.md), [verifikacioni slice](E01_VERIFICATION_SLICE_17.md) i [G1b publikacioni manifest](PUBLICATION_MANIFEST_18.md). `method_run_002` prikazuje 5 kandidata/15 događaja: 2 javno dokumentovana režima bez terenske potvrde, 1 odbijenu potvrdu istog porekla i 2 nerazrešena spoja dokument–tačka. Javni pilot je živ i browser-proveren: https://3esign.github.io/sportspace-pilot/

- Aktuelno v0.16: [browser QA i spremnost za prvi pilot](E01_PILOT_READINESS_16.md). Stvarni Chromium render proverava 390, 768, 1440 i 1920 px, bez horizontalnog prelivanja, page/console grešaka ili pada osnovnih interakcija. Ispravljen je mobilni Canvas/grid overflow. Repo još nema Git remote; G1b klasifikacija javnih OSM-izvedenih artefakata i pet nezavisnih verification događaja ostaju obavezne kapije prvog istraživačkog pilota.

- Aktuelno v0.13: [AOI i OSM snapshot za E01-clean](AOI_I_OSM_SNAPSHOT_13.md). Zaključan je tehnički AOI-1 prozor za Stup/Stup II/Stupsko Brdo, bez tvrdnje da je službena granica. Napravljen je lokalni OSM snapshot za AOI + buffer, dokazni summary, 12 OSM-derived activity kandidata i prazan verification log. Reviewer je ispravio da OSM `access=yes` ne sme postati `public_documented`; svi kandidati ostaju `access_model=unknown` dok ne prođu nezavisnu proveru.

- Aktuelno v0.12: [E01 input table](E01_INPUT_TABLE_12.md). Definisani su konkretni ulazi, snapshot-i, polja, kapije i minimalni `method_run_001` za E01-clean. Reviewer je dodao dve obavezne kapije: svaka nezavisna provera mora beležiti nezavisnost od OSM/ulaznog izvora, a svaki javni OSM-zavisni artefakt mora imati Produced Work / Derived Database / private-only klasifikaciju pre objave.

- Aktuelno v0.11: [related-work outline za rad](RELATED_WORK_OUTLINE_11.md). v0.10 je prepakovan u pisljiv argument sa pet related-work celina, suzenim pozicioniranjem "method-gated evidence interaction" i apstrakt kosturom. Reviewer je ispravio formulacije koje su mogle zvucati kao da E01/GIS prototip vec radi ili kao da je praznina empirijski dokazana; status ostaje plan/specifikacija do prvog `method_run`.

- Aktuelno v0.10: [pregled literature i pozicioniranje inovacije](LITERATURE_REVIEW_10.md). Prvi naucni pilot se suzava na E01-clean: proverljiva dostupnost prostora za aktivnost, sa dokaznim statusom ulaza, mreze, rezima i objekata. E02/ambijentalni slojevi ostaju sledeca kapija dok ne dobiju direktnu literaturu i validaciju.

- Aktuelno v0.9: [okvir specijalističkog GIS-a i put do GitHub prototipa](OKVIR_I_PUT_DO_PROTOTIPA_09.md), [interaktivna dizajnerska skica](design/index.html), [provere skice](design/README.md). Mapa je glavni UI/UX; skica koristi izmišljenu geometriju. Nema operativnih GIS/AI rezultata ili javne objave.

- Ugovori v0.8: [sistem podataka, dokaza i eksperimentalnih metoda](SISTEM_DOKAZA_I_METODA_08.md), [ugovor izvora](contracts/data-and-evidence.json), [registar metoda](contracts/experimental-methods.json). Definisani loop i rezultati za UI; sistem jos nije implementiran.
- Plan iskustva v0.7: [plan interaktivnog atlasa i metoda](INTERFEJS_I_METOD_07.md). Fokus Ilidza/Stup; prostorna inspekcija, povezani prikazi i poredjenje. Operativni GIS i GitHub sajt još nisu napravljeni; skica je dodata u v0.9.
- Podatkovna osnova v0.6: [baze, prostorne veze i pet predlozenih mapa](BAZE_I_KARTE_06.md), [novi izvori](IZVORI_06.md). Korisnik je usmerio metod ka stvarno dostupnim podacima; GBIF proveren, vazduh Ilidza2024 pripremljen. Zavrsne karte jos nisu napravljene.
- Prethodno v0.5: [nevidljive pretpostavke i unknown unknowns](NEVIDLJIVE_PRETPOSTAVKE_05.md), [15 izvora sa granicama](IZVORI_05.md). Korisnik trazi dublje istrazivanje; tema ostaje otvorena.
- Prethodni atlas v0.4: [veliki atlas24tema](ATLAS_TEMA_04.md) u šest područja, [21novi izvor i granice dostupnosti](IZVORI_04.md). Korisnik traži širok talas; nijedan kandidat nije izabran.
- Prethodna razrada: [živi metar](ZIVI_METAR.md), v0.3. Najnovija korekcija određuje da je to samo jedan koncept, sada T24, bez povlašćenog statusa.
- Istorijski drugi talas: [planerska pitanja](TALAS_02_PLANERSKI_ALAT.md), [20 izvora i lokalne provere](SLOJEVI_02.md), 19.09.2026.
- Metakontekst v0.1, 19.09.2026: [glavni dokument](METAKONTEKST.md).
- [27 otvorenih pitanja](NEPOZNANICE.md), [19 izvora i kandidata](IZVORI.md), [lokalni prethodnici](NASLEDJE.md), [trag pretrage](PRETRAGA.md).
- [Sadržajna revizija](REVIZIJA.md): odvojena procena unutrašnje logike; originalni izvori nisu nezavisno potvrđeni.
- Pilot je implementiran i lokalno browser-proveren; javna GitHub Pages objava i terenska validacija vode se kao odvojeni statusi.
- Istraživački program: `koje-proverljive-naucne-tvrdnje-o-dostupnosti-sporta-i-r`; kanonski checkpoint u `C:/Svemir/data/research/programs/koje-proverljive-naucne-tvrdnje-o-dostupnosti-sporta-i-r/state.json`.
- Ulaz za nastavak: taj checkpoint, `UPUTSTVO.md`, `LOG.md`, `RECNIK.jsonl`, `KNOWLEDGE.md`.

## Trenutni tehnički rezultat — v0.14 method_run_001

E01-clean sada ima prvi ponovljiv prostorni run: 20 sintetičkih origin tačaka, 12 OSM izvedenih kandidata, 240 origin–kandidat parova i 228 rutiranih parova kroz osnovni OSM pešački graf. Rezultat je zapisan u `E01_METHOD_RUN_14.md`, `data/results/e01/method_run_001.json` i `data/results/e01/method_run_001.summary.json`. Svi kandidati ostaju `access_model: unknown`; ovo je metodski/UI sloj, ne javna tvrdnja o dostupnosti ili zdravlju. Evidence fajl: `evidence/e01-method-run-001-2026-09-19T19-08-30-827Z.json`.

## Sledeći korak

Sledeći potez je v0.17 verification slice: unapred izabrati pet različitih kandidata, za svaki prikupiti datiran i od OSM-a nezavisan dokaz za postojanje, ulaz i režim pristupa, zapisati događaje u `verification_events.jsonl`, pa ponoviti E01 račun tako da UI pokaže prelaz `unknown → verified/documented/conflict`. Paralelno treba završiti G1b klasifikaciju tačno onih OSM-izvedenih fajlova koji ulaze u javni paket. Tek zatim ima smisla podesiti GitHub remote i Pages.

## Trenutni tehnički rezultat — v0.15 site prototype

E01 sada ima prvi statički GitHub-ready method-map prototip u `site/`. On čita izvedeni paket iz `site/data/sportspace-data.js`, prikazuje AOI, kandidate, origin tačke, najbliže mrežne odnose, nerutirane slučajeve, dedupe status i evidence panel. Svi kandidati ostaju `access_model: unknown`; prototip je metodski/UI dokaz, ne javni zaključak o dostupnosti ili zdravlju. Detalji: `E01_SITE_PROTOTYPE_15.md`.

## Trenutni tehnički rezultat — v0.16 browser QA

Ponovljiv QA alat `tools/site-qa-v016.cjs` koristi postojeći lokalni Playwright runtime bez projektnih zavisnosti. Proverava četiri širine, reduced-motion, promenu režima, izbor kandidata i origina, A/B čuvanje, reset, prvi tastaturni fokus i browser greške. Izlaz je `site/review/qa.json`; screenshotovi su u `site/review/`. Detalji i pilot kapije: `E01_PILOT_READINESS_16.md`.


</details>


</details>
