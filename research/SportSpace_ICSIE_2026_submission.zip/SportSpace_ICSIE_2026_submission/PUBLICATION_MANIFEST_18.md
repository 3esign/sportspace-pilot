# G1b publication manifest · v0.18

Ovaj manifest određuje šta ulazi u javni GitHub Pages pilot.

| artefakt | klasifikacija | javno | uslov |
|---|---|---:|---|
| sirovi OSM Overpass snapshot | privatni radni ulaz | ne | ostaje lokalno i ignorisano |
| pešački graf | privatni radni ulaz | ne | veliki izvedeni graf nije potreban browseru |
| `site/data/sportspace-data.js` | javna izvedena baza | da | ODbL 1.0, vidljiva atribucija i data notice |
| `site/data/manifest.json` | javni provenance manifest | da | isti data notice |
| Canvas mapa i screenshot prikaz | Produced Work | da | vidljiva OSM atribucija |
| HTML, CSS, JavaScript i build/QA kod | autorski kod | da | MIT |
| registar izvora i događaji provere | istraživački metapodaci | samo sažeti podaci | URL i parafrazirane činjenice; bez kopiranja stranica, slika ili PDF-a |
| lokalni dosije, radne beleške i istorija | privatni istraživački materijal | ne | javni repo se gradi isključivo iz allowliste |

Javni paket sadrži samo statički sajt, izvedene browser podatke, manifest, licence i obaveštenja. Ne sadrži lokalne putanje, tajne, sirovi OSM odgovor, pešački graf ili internu istoriju projekta.


## v0.21 — novi prikazni artefakti

- `site/data/display-data.js`: zasebna javna izvedena ODbL baza sa kartografskim obrisima i rekonstruisanim putanjama. Nije sirovi snapshot niti ceo pešački graf.
- `site/data/display-manifest.json`: javni hash-evi, brojnosti, poreklo i granice prikaza.
- `private/v021/context-raw.json`: lokalni sirovi ulaz, ne ulazi u javni paket.
- `site/scene3d.js`: autorski MIT kod; WebGL prikaz je Produced Work uz OSM atribuciju.
- Visine iz OSM oznake ili procene 3 m po etaži ostaju jasno označene; nepoznate ravno.
- `release/github-pages-v021`: pregledan paket iz nove eksplicitne allowliste; priprema nije objava.

## v0.22 — stakeholder workflows, locally prepared

New site/planning.js and planning.css are first-party MIT application code. They calculate sensitivity from the existing public ODbL run and do not introduce raw/private sources. Exported scenario CSV is OSM-derived analytical output: retain ODbL provenance and source run identifier/hash. Authors and affiliation were explicitly supplied/confirmed by the user for display. Screenshot email content is not included in the public package.

The explicit allowlist builder tools/public-release-build-v022.cjs preserves prior packages and copies only site assets into release/github-pages-v022. Root working notes, QA images, correspondence and raw/private inputs are not swept into a publication. README/AUTHORS/CITATION/research plan in the project are local preparation for a future research repository; final release and paper metadata remain pending.

## v0.23 — reviewed environmental data and research inputs

WorldCover2021 clip/georeference and CAMS/Open-Meteo2021 hourly JSON are CC BY4.0 with named attribution; no2024station extract included. OSM-linked combined metrics retain ODbL-derived database obligations plus attribution of CC BY inputs. Application/indicator implementation is MIT. Tree geometry is code-generated symbolic display, not redistributed model assets.

Explicit allowlist: tools/public-release-build-v023.cjs. It includes exact CC BY inputs, retrieval metadata and a portable offline analytical builder so the environmental results can be rebuilt. No whole-workspace publishing, correspondence, raw private OSM archive, contact information, credentials or user geolocation. This prepared package is local, not deployed.
