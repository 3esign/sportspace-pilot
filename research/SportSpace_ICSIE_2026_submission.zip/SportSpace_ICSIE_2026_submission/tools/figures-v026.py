"""Scientific figures from saved SportSpace outputs. No network or recalibration."""
import os,sys,json,hashlib
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap,BoundaryNorm
from matplotlib.patches import Rectangle
ROOT=Path(os.environ.get('SPORTSPACE_ROOT',str(Path(__file__).resolve().parents[1])))
OUT=Path(os.environ.get('SPORTSPACE_FIGURES',str(ROOT/'paper/figures/v026')))
OUT.mkdir(parents=True,exist_ok=True)
inputs={}
def read(rel):
 p=ROOT/rel;b=p.read_bytes();inputs[rel]=hashlib.sha256(b).hexdigest()
 if rel.endswith('.js'):return json.loads(b.decode('utf-8-sig').split('=',1)[1].strip().removesuffix(';'))
 return json.loads(b)
base='data/processed/science/v025/'
data=read('site/data/sportspace-data.js');e1=read(base+'e1-access.json');e2=read(base+'e2-sensitivity.json');e3=read(base+'e3-temporal.json');buf=read(base+'precise-buffers.json')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':11,'axes.labelsize':9,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42,'savefig.dpi':300})
green='#245c50';purple='#706095';amber='#b37535';gray='#697878';outputs=[];plotdata={}
def save(fig,name):
 for ext in ['svg','pdf','png']:
  p=OUT/(name+'.'+ext);fig.savefig(p,bbox_inches='tight',facecolor='white',metadata={'Creator':'SportSpace'} if ext=='pdf' else None);outputs.append(p.name)
 plt.close(fig)

# Figure1: coordinates are actual source locations; the frame is a work window.
fig,ax=plt.subplots(figsize=(7.1,4.3));box=[18.300,43.828,18.352,43.850]
ax.add_patch(Rectangle((box[0],box[1]),box[2]-box[0],box[3]-box[1],fill=False,edgecolor=gray,linestyle='--',linewidth=1))
origins=data['origins']['features'];bad={x['origin'] for x in e1 if x['activity']=='all' and not x['routed']}
for failed,marker,color,label in [(False,'o',gray,'Synthetic origin'),(True,'x',amber,'Origin without modelled routes')]:
 pts=[x['geometry']['coordinates'] for x in origins if (x['id'] in bad)==failed]
 ax.scatter(*np.array(pts).T,s=22,marker=marker,color=color,label=label,zorder=3)
for activity,marker,color,label in [('playground','^',green,'Playground (8)'),('sports_centre','s',purple,'Sports centre (3)'),('pitch','D',amber,'Sports pitch (1)')]:
 pts=[x['point'] for x in buf if x['activity']==activity];ax.scatter(*np.array(pts).T,s=40,marker=marker,color=color,label=label,zorder=4)
ax.set(xlim=(18.297,18.355),ylim=(43.825,43.853),xlabel='Longitude (°E)',ylabel='Latitude (°N)',title='Pilot geometry and synthetic sampling')
ax.ticklabel_format(useOffset=False);ax.set_aspect(1/np.cos(np.deg2rad(43.839)));ax.grid(alpha=.17)
ax.legend(loc='upper center',bbox_to_anchor=(.5,-.21),ncol=2,frameon=False,fontsize=8)
fig.text(.5,-.31,'Dashed frame: technical work window, not an administrative boundary.\nPoints do not establish entrances, public access or population demand.',ha='center',fontsize=8,color=gray)
plotdata['figure1']={'origins':len(origins),'destinations':len(buf),'unroutable':sorted(bad),'work_window':box};save(fig,'figure1-study-geometry')

# Figure2: all synthetic origins, with missing origin explicitly masked.
ids=sorted({x['origin'] for x in e1});short=lambda s:s.replace('grid-','').replace('-','/')
fig,axes=plt.subplots(1,2,figsize=(7.1,5.4),sharey=True)
for ax,activity,title,color in zip(axes,['playground','sports_centre'],['Playgrounds','Sports centres'],[green,purple]):
 rows={x['origin']:x for x in e1 if x['activity']==activity};vals=[rows[i]['additional_minutes_to_air_nearest'] for i in ids]
 ax.barh(range(20),[0 if v is None else v for v in vals],height=.65,color=color)
 for k,v in enumerate(vals):
  if v is None:ax.text(.12,k,'No route',va='center',fontsize=7,color=amber)
  elif v>0:ax.text(v+.1,k,f'{v:.2f}',va='center',fontsize=7)
  else:ax.plot(0,k,'o',color=color,ms=2)
 ax.set(xlim=(0,11.5),title=title,xlabel='Additional walking time (min)',yticks=range(20),yticklabels=[short(i) for i in ids]);ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True)
 plotdata['figure2-'+activity]=dict(zip(ids,vals))
axes[0].invert_yaxis();fig.suptitle('Cost of choosing a straight-line nearest destination',y=1.02,fontsize=11)
fig.text(.5,-.02,'Compared with the network nearest in the same activity; 1.2 m/s assumed speed.\nDots at zero indicate no additional time; row/column labels identify synthetic origins.',ha='center',fontsize=8,color=gray);fig.tight_layout();save(fig,'figure2-network-choice')

# Figure3: one row per origin, one column per threshold; no repeated green thresholds.
fig,ax=plt.subplots(figsize=(7.1,5.3));matrix=[]
for i in ids:
 row=[]
 for t in [10,20,30]:
  a=next(x for x in e2 if x['origin']==i and x['activity']=='playground' and x['radius_m']==100 and x['time_threshold_min']==t and x['green_threshold_pct']==10)
  b=next(x for x in e2 if x['origin']==i and x['activity']=='playground' and x['radius_m']==500 and x['time_threshold_min']==t and x['green_threshold_pct']==10)
  row.append(-1 if not a['routed'] else int(set(a['pareto_ids'])!=set(b['pareto_ids'])))
 matrix.append(row)
m=np.array(matrix);assert int((m==1).sum())==20 and int((m>=0).sum())==57
cmap=ListedColormap(['#e0e0e0','#ecf2ef',green]);ax.imshow(m,cmap=cmap,norm=BoundaryNorm([-1.5,-.5,.5,1.5],3),aspect='auto')
for r in range(20):
 for c in range(3):ax.text(c,r,{-1:'?',0:'=',1:'Δ'}[m[r,c]],ha='center',va='center',color='white' if m[r,c]==1 else gray,fontsize=9)
ax.set(xticks=range(3),xticklabels=['10 min','20 min','30 min'],yticks=range(20),yticklabels=[short(i) for i in ids],xlabel='One-way time threshold',title='Playground Pareto membership: 100 m versus 500 m vegetation buffer')
fig.text(.5,-.015,'Δ Changed set (20/57)     = Same set, including empty sets     ? No route\nPareto criteria: less travel time and more vegetation. No green-percentage cutoff applied.',ha='center',fontsize=8,color=gray);fig.tight_layout();plotdata['figure3']={'origins':ids,'thresholds':[10,20,30],'matrix':matrix};save(fig,'figure3-radius-sensitivity')

# Figure4: paired differences, not differences of separately aggregated medians.
fig,axes=plt.subplots(2,2,figsize=(7.1,5.1),sharex=True,sharey=True)
for ax,p,label in zip(axes.flat,['pm2_5','pm10','nitrogen_dioxide','ozone'],['PM2.5','PM10','NO2','O3']):
 row=next(x for x in e3 if x['stay_min']==30 and x['pollutant']==p);ds=[row['paired_differences'][k] for k in ['14-08','18-08','18-14']]
 for y,d in enumerate(ds):
  ax.plot([d['p10'],d['p90']],[y,y],color=green,lw=2);ax.plot(d['median'],y,'o',color=purple,ms=5)
 ax.axvline(0,color=gray,lw=.8,ls='--');ax.set(title=label,yticks=range(3),yticklabels=['14:00 − 08:00','18:00 − 08:00','18:00 − 14:00']);ax.grid(axis='x',alpha=.15)
 plotdata['figure4-'+p]=ds
axes[0,0].invert_yaxis();fig.supxlabel('Paired concentration–time difference (µg·min/m³)',y=.045,fontsize=9)
fig.text(.5,-.035,'Dot: median; segment: 10th–90th percentiles (not a confidence interval).\n83,220 paired scenarios per pollutant; shared regional 2021 series; 30-minute stay.',ha='center',fontsize=8,color=gray);fig.tight_layout(rect=(0,.07,1,1));save(fig,'figure4-departure-differences')
(OUT/'plotted-values.json').write_text(json.dumps(plotdata,indent=2,ensure_ascii=False),encoding='utf8')
manifest={'inputs':inputs,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'matplotlib':matplotlib.__version__,'numpy':np.__version__,'outputs':{n:hashlib.sha256((OUT/n).read_bytes()).hexdigest() for n in outputs},'limits':['No UI changes','No new environmental model','No station validation','Visual review required']}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8');print(json.dumps({'figures':len(outputs)//3,'outputs':str(OUT)}))
