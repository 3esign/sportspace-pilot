"""A calculated planning map; no interpolation or new environmental estimates."""
import os,json,hashlib
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.lines import Line2D
from matplotlib.patches import Patch,Rectangle
root=Path(os.environ.get('SPORTSPACE_ROOT',str(Path(__file__).resolve().parents[1])))
out=Path(os.environ.get('SPORTSPACE_MAP_OUT',str(root/'paper/figures/v027')));out.mkdir(parents=True,exist_ok=True);inputs={}
def read(p,binary=False):
 b=(root/p).read_bytes();inputs[p]=hashlib.sha256(b).hexdigest()
 if binary:return b
 return json.loads(b.decode('utf8').split('=',1)[1].strip().removesuffix(';')) if p.endswith('.js') else json.loads(b)
d=read('site/data/sportspace-data.js');display=read('site/data/display-data.js');e=read('data/processed/science/v025/e2-sensitivity.json');buf=read('data/processed/science/v025/precise-buffers.json');meta=read('data/processed/environment/worldcover2021-clip.json');raster=np.frombuffer(read('data/processed/environment/worldcover2021-clip.bin',True),dtype=np.uint8).reshape(meta['height'],meta['width'])
rgba=np.empty((*raster.shape,4));rgba[:]=[.97,.97,.95,1];veg=np.isin(raster,[10,20,30,90,95,100]);rgba[veg]=[.72,.81,.68,1];rgba[raster==80]=[.61,.78,.82,1]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(figsize=(9.0,5.9));fig.subplots_adjust(left=.09,right=.98,top=.85,bottom=.24)
sx,sy=meta['pixel_size'];ax.imshow(rgba,extent=[meta['west'],meta['west']+meta['width']*sx,meta['north']-meta['height']*sy,meta['north']],origin='upper',interpolation='nearest',zorder=0)
roads=[x['p'] for x in display['roads']];ax.add_collection(LineCollection(roads,colors='#a7b2ae',linewidths=.40,alpha=.70,zorder=1))
box=[18.300,43.828,18.352,43.850];ax.add_patch(Rectangle((box[0],box[1]),box[2]-box[0],box[3]-box[1],fill=False,ls='--',ec='#596b65',lw=.8,zorder=2))
selected=[x for x in e if x['activity']=='playground' and x['radius_m']==300 and x['time_threshold_min']==20 and x['green_threshold_pct']==20];rows={x['origin']:x for x in selected};maxn=max(x['joint_count'] or 0 for x in selected);values=[]
for f in d['origins']['features']:
 row=rows[f['id']];x,y=f['geometry']['coordinates'];n=row['joint_count'];known=bool(row['routed']);label=str(n) if known else '?';color=plt.cm.Greens(.12+.68*n/max(1,maxn)) if known else '#dfdfdf'
 ax.scatter(x,y,s=310,c=[color],edgecolors='#314d43',linewidths=.7,zorder=6);ax.text(x,y,label,ha='center',va='center',fontweight='bold',fontsize=10,color='white' if known and n>=maxn*.7 and n>0 else '#223c33',zorder=7)
 values.append({'origin':f['id'],'coordinates':[x,y],'count':n if known else None,'eligible_ids':row['joint_ids'],'routed':known})
for eligible,fc in [(False,'white'),(True,'#194f42')]:
 pts=[c['point'] for c in buf if c['activity']=='playground' and (c['buffers']['300']['vegetation_pct']>=20)==eligible];a=np.array(pts)
 if len(a):ax.scatter(a[:,0],a[:,1],s=45,marker='^',facecolors=fc,edgecolors='#194f42',linewidths=.8,zorder=8)
ax.set(xlim=(18.298,18.354),ylim=(43.8265,43.8515),xlabel='Longitude (°E)',ylabel='Latitude (°N)');ax.ticklabel_format(useOffset=False);ax.set_aspect(1/np.cos(np.deg2rad(43.839)))
ax.annotate('N',xy=(18.3525,43.8498),xytext=(18.3525,43.8476),ha='center',fontsize=8,arrowprops={'arrowstyle':'-|>','color':'#223c33'},zorder=10)
# Approximate local longitude scale; not geodesic surveying accuracy.
deg500=500/(6371008.8*np.cos(np.deg2rad(43.839))*np.pi/180);ax.plot([18.3005,18.3005+deg500],[43.8273,43.8273],color='#223c33',lw=2);ax.text(18.3005+deg500/2,43.8269,'500 m',ha='center',fontsize=7,bbox={'fc':'white','ec':'none','alpha':.8,'pad':1})
fig.suptitle('Spatial screening of recreation opportunities',fontsize=14,y=.97)
fig.text(.5,.915,'Playground candidates · 20 min one-way · ≥20% vegetation within 300 m',ha='center',fontsize=10,color='#245c50')
handles=[Line2D([],[],marker='o',mfc='#c4dfba',mec='#314d43',ls='',ms=10,label='Number: qualifying candidates from this origin'),Line2D([],[],marker='^',mfc='#194f42',mec='#194f42',ls='',ms=6,label='Candidate meets vegetation condition'),Line2D([],[],marker='^',mfc='white',mec='#194f42',ls='',ms=6,label='Other playground candidate'),Patch(fc='#b8cfad',label='Satellite vegetation classes'),Patch(fc='#9cc7d1',label='Satellite water class')]
fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,.075),ncol=2,frameon=False,fontsize=8)
fig.text(.5,.045,'? No modelled route. Thresholds are analytical settings, not planning or health standards.',ha='center',fontsize=8,color='#586b62')
fig.text(.5,.012,'OSM © contributors (2026) · ESA WorldCover 2021 / modified Copernicus Sentinel data · Baseline graph',ha='center',fontsize=7,color='#586b62')
for ext in ['png','svg','pdf']:fig.savefig(out/('figure5-planning-map.'+ext),dpi=300,bbox_inches='tight',facecolor='white')
plt.close(fig)
result={'inputs':inputs,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scenario':{'activity':'playground','time_threshold_min':20,'green_threshold_pct':20,'buffer_radius_m':300,'network':'v025baseline','interpretation':'Synthetic origin counts only; no catchment, interpolation, population or verified access'},'origins':values,'candidate_vegetation':[{k:c[k] for k in ['id','point','activity']}|{'vegetation_300m_pct':c['buffers']['300']['vegetation_pct']} for c in buf if c['activity']=='playground'],'output_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('figure5*')}}
(out/'planning-map-values.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf8');print(json.dumps({'max_count':maxn,'values':[x['count'] for x in values]}))
