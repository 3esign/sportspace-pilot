# Ponovljivost

## Dva nivoa reprodukcije

**Interfejs i scenariji:** otvori `site/index.html` u savremenom pregledaču ili posluži `site/` kao statički direktorijum. Nema instalacije paketa, spoljašnjih zahteva pri prikazu ili API ključeva. Javne izvedene datoteke u `site/data/` dovoljne su za čitanje rezultata i računanje scenarija. 3D zahteva WebGL; 2D i lista zadržavaju pristup podacima bez njega.

**Potpuna obnova podataka:** builder `tools/site-display-build-v021.cjs` koristi originalni graf i privatni kontekstualni OSM snimak. Ovi ulazi nisu svi u javnom paketu. Zato javni paket reprodukuje scenario iz objavljenog rezultata, ali sam ne reprodukuje ceo put od sirovih izvora. Pre istraživačkog izdanja treba objaviti dozvoljene ulaze ili precizan legalan postupak njihovog preuzimanja i provere hashova.

## Račun scenarija v0.22

Ulaz je neizmenjen `method_run_002`, ne nova simulacija kretanja. Za polazište o, skup kandidata iste aktivnosti C i prag t, broji se broj parova sa konačnim mrežnim rezultatom i `travel_time_min <= t`. Jedinica je minut u jednom smeru; model koristi 1,2 m/s.

Scenario izuzimanja e koristi isti skup bez kandidata e. Broj polazišta sa makar jednom opcijom dobija se pre i posle izuzimanja. `lost` broji polazišta koja su imala opciju i ostala bez nje. Polazišta bez mrežnog rezultata u osnovi prikazuju se posebno. Nedostajući rezultat ne pretvara se u nula minuta. Brojevi nisu udeo stanovništva ili zdravlja.

Kod računanja: `site/planning.js`, funkcija `evaluate`, ujedno dostupna kao CommonJS export radi nezavisne provere. Ulična mreža, vremena drugih parova i postojeći naučni run ostaju isti. Prag koristi numeričko vreme iz objavljenog run-a, ne zaokružen tekst iz interfejsa.

CSV sadrži aktivnost, prag, brzinu, izuzetog kandidata, identifikator polazišta, broj opcija pre/posle, najbliža vremena, oznaku nedostajuće veze, identifikator run-a i njegov SHA-256. Prazna numerička ćelija znači nedostajući rezultat. Test proverava graničnu vrednost praga i nedostajuće veze.

## Provere

Iz korena projekta, sa Node.js:

```text
node tests/planning-v022.test.cjs
node tools/site-validate-v021.cjs
node tests/ui-v022.test.cjs
node tests/ui-v021.test.cjs
node tests/ux-resilience.test.cjs
```

UI testovi koriste postojeću instalaciju Playwright-a na radnoj mašini; to nije dodata zavisnost aplikacije. Čista mašina bez Playwright-a može da izvrši prvi test i validator, a UI proveru treba posebno pripremiti. Rezultati su pod `review/v022/`, stari testovi pišu u `review/v021/`. Merila: tačnost brojanja, nedostajuće veze, interakcije oba toka, CSV, prelaz na mapu, mobilni raspored, očuvan 2D/3D i odsustvo JavaScript grešaka.

## Objava

v0.22 je lokalni razvoj. Raniji javni v0.19 i pripremljeni v0.21 paket nisu ovo izdanje. Nijedan Git push, Pages deploy ili DOI registracija ne prati lokalnu izmenu automatski. Repo za naučno izdanje treba da ima tačno označenu verziju, manifest izvora/licenci, proverenu obnovu dozvoljenih ulaza, dokumentovan rad sa nedostajućim podacima, autorstvo i snimak QA. Sačuvati ranije rezultate kao istoriju.

## v0.23 — environmental analysis and model views

No new measurements required. Online acquisition: node tools/environment-acquire-v023.cjs (uses local incognito header provider; network access needed). Offline computation: node tools/environment-build-v023.cjs. Raw CC BY air data and raster extract+georeference are preserved under data/raw/environment/v023 and data/processed/environment. The initial crop is reproducible from the saved range manifest and acquisition script; the92MB parent file is not bundled.

Checks: node tests/environment-v023.test.cjs; node tests/ui-v023.test.cjs; prior v021/v022 regressions. Independent haversine comparison covers six destination buffers; difference≤0.036pp. Air chronology and all48monthly means checked. Source files identified by SHA-256, not mutable API timing.

The new prepared release includes source clips, hourly air, manifests and offline builder. Run node tools/environment-build-v023.cjs from the extracted package; it detects flat-site layout. This reconstructs the environmental analysis from published inputs and existing baseline results, not the original OSM routing graph. Three model families are implemented in site/access-models.js (or access-models.js in flat release).
