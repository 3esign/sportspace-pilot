# ICSIE 2026 — provjereni zahtjevi i stanje rukopisa

Provjera 20.09.2026. Izvor: https://sisli.edu.tr/icsie/full-text-submission/
Službeni prilog: https://sisli.edu.tr/icsie/wp-content/uploads/2026/07/ICSIE-TAM-METIN-YAZIM-SABLONU-FULL-PAPER-TEMPLATE.docx
Sačuvana neizmijenjena kopija: templates/ICSIE-2026-official.docx.
SHA256 e622a88f55f29fca7e69e5f74d2446232f1b5ebb8a23772ab5d7e2a6c037ff67.

## Zahtjevi

| Element | Službeni zahtjev | Primjena |
|---|---|---|
| Jezik | engleski ili turski | engleski rukopis; jezik aplikacije ostaje odvojen |
| Opseg | 6–15 stranica, uključujući reference, tabele i priloge | još nije izmjeren prelom |
| Format | Microsoft Word .docx | završni izvoz nakon vizuelne provjere |
| Papir | A4,210×297mm; margine2.5cm | tekstualno pravilo ima prednost nad pogrešnom postavkom predloška |
| Osnovni tekst | Times New Roman12pt; jednostruki prored; obostrano poravnanje; prvi red0.75cm; poslije6pt | za budući Word izvoz |
| Naslov |14pt,bold,centrirano,Title Case | naslov o konkretnom predmetu |
| Autori |11pt,centrirano,ime PREZIME | Semir prvi, Amra druga |
| Autorska fusnota |titula,afilijacija,ORCID,e-mail | titule i ustanova poznate; SemirovORCID potvrđen; e-mail i AmriniORCID/e-mail dopuniti |
| Sažetak |200–300riječi,jedan pasus,11pt; naslov12ptbold | kontrola broja riječi u manuscript-check.json |
| Ključne riječi |3–5,abecedno,11pt |5engleskihpojmova |
| Poglavlja |1Introduction;2Literature Review;3Methodology;4Findings;5Discussion;6Conclusion;References | isti redoslijed u nacrtu |
| Naslovi poglavlja |12ptbold | zadržati pri izvozu |
| Tabele/slike |naziv tabele iznad; naziv slike ispod;11pt |3tabele u nacrtu; figure još nisu izrađene |
| Reference |APA7,11pt,viseciuvlak1.25cm | radni bibliografski zapisi; konačnu bibliografiju još pregledati |

## Neslaganje izvornog Word fajla

word/document.xml sectPr/pgSz ima12240×15840twips (Letter,8.5×11in), dok pasus3 izričito tražiA4. Margine1417twips odgovaraju približno2.5cm. Normal stil ima Times New Roman12pt,6ptposlije,jednostruko,prvired425twips. Prilikom izvoza slijediti napisano A4 pravilo i evidentirati promjenu geometrije; ne prepisivati original.

Dokument sadrži autorske fusnote sa metapodacima. Pregled samo glavnih pasusa ih ne bi pronašao. Nema zasebnih header/footer dijelova. Paket stilova je opširan; pri budućem izvozu ne zamijeniti ga generičkim dizajnom.

## Otvorene kapije

- CONTENT_DRAFT: sva glavna poglavlja napisana; ne predstavlja spremnost za predaju.
- NUMERICAL_SUPPORT: provjereni v0.25računi; zaseban pregled nacrta prati tačan fajl.
- FORMAT_RENDER: BLOCKED. Packaged render_docx.py izvršen nad originalom; FileNotFoundError: LibreOffice soffice.exe was not found on PATH. Dependency loader ne navodi bundled LibreOffice; nije korišten desktop program niti instalirana nova biblioteka. Zbog toga nema potvrđenog broja stranica niti vizuelnog odobrenja DOCX-a.
- FIGURES: NOT_RUN; planirati obuhvat/prostornu potporu, Pareto kompromis i vremenski obrazac iz postojećih izlaza. Tabele nisu dokaz da su figure proizvedene.
- AUTHOR_METADATA: SemirovORCID0009-0004-1537-2074 javno povezan sa https://github.com/3esign, provjeren20.09.2026. E-mail nije prikazan na otvorenoj profilnoj stranici; git commit adresu ne pretvarati automatski u korespondencijsku. Amrini detalji stižu naknadno prema korisniku.
- RELEASE: v0.25analitički paket još nije javno izdanje; nema izmišljenog taga/DOI-ja.
- SUBMISSION: nije poslan e-mail ni rukopis. Uputstvo webstranice o adresi predaje je formatni zahtjev, ne nalog korisnika za slanje.

## Honest verdict

Provjereno: službena stranica, preuzeti Word paket, tekstualna pravila, fusnote, konkretan konfliktA4/Letter i dostupnost renderera. Zaključeno: engleski nacrt prati odjeljke i dokazni domet rada. Nije provjereno: konačan Word izgled i broj stranica, potpuna bibliografska spremnost, autorsko odobrenje i predaja.

## Dopuna — figure20.09.2026
Četiri figure izrađene iz sačuvanihanalitičkihizlaza, uključene u nacrt sa numerisanimopisima. IzvozPNG300dpi,SVG,PDF i manifest: paper/figures/v026/. RanijiFIGURES:NOT_RUN je historijsko stanje; DOCXprelom i brojstranica i dalje nisu provjereni.
