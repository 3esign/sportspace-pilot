# SportSpace scientific figures v0.26

Four figures generated directly from saved v0.25 analytical outputs, with PNG300dpi, vectorSVG andPDF exports. Captions in manuscript. No UI changes.

## Reproduce

Python3.12, matplotlib3.11.2 and numpy2.3.5 were used. Supporting plotting packages: contourpy1.4.0,cycler0.12.1,fonttools4.65.0,kiwisolver1.5.1,pyparsing3.3.2. These are isolated publication tooling, not backend or app dependencies. No npm packages added.

Run python tools/figures-v026.py from a Python environment with matplotlib and numpy. SPORTSPACE_ROOT and SPORTSPACE_FIGURES optionally override the project/input and output directories. Set MPLCONFIGDIR to a writable cache directory if necessary. This performs no network access.

manifest.json links script and exact source hashes to output hashes. plotted-values.json records every statistical quantity used. Graphical export metadata can change byte hashes between runs; identical plotted values are the numerical reproducibility criterion.

## What the figures establish

1. figure1-study-geometry: Origins are the centres of a 4 × 5 synthetic grid; markers show the twelve pilot destinations. The dashed rectangle is the technical work window. The crossed origin has no modelled route. Nearby destination markers may overlap; coordinates are not displaced. Coordinates describe the sampling design, not verified entrances, public access or population demand.

2. figure2-network-choice: Additional modelled walking time incurred by choosing a straight-line nearest destination rather than the network nearest of the same activity. All twenty synthetic origins are displayed; one lacks routes. Tied straight-line minima use the least costly network option. Zero is shown as a dot. These results are conditional on the baseline directionality, snapping and 1.2 m/s walking-speed assumptions.

3. figure3-radius-sensitivity: Change in the playground Pareto set when the vegetation buffer increases from 100 to 500 m, for each origin and one-way time threshold. Twenty of fifty-seven valid comparisons change; missing-origin cases are excluded from the denominator. Equal sets include empty sets. Pareto criteria are travel time and vegetation percentage, before a separate vegetation-threshold filter.

4. figure4-departure-differences: Paired concentration–time differences between local departure times for a thirty-minute stay and assumed symmetric return. Points show medians; segments span the 10th–90th percentiles of 83,220 date–route scenarios per pollutant. Segments are descriptive ranges, not confidence intervals. Negative values mean a smaller integral at the first labelled time. A common numerical scale does not equate health effects between pollutants. All cases share the regional 2021 series; they are not independent observations or current recommendations.

## Review

All four renderedPNGfiles inspected. Initial figure1footer/legend overlap corrected before delivery. No station validation, causal effect or usability benefit follows from graphic quality. DOCX integration/pagecount still requires a document renderer.
