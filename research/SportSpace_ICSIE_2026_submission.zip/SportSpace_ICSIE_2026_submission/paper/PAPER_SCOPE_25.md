# SportSpace — definisan obim rada i uključivanje zraka i meteorologije

Datum odluke: 20.09.2026. Status: istraživački dizajn za postojeći pilot; nove analize nisu izvršene ovim dokumentom. Nastavlja paper/RESEARCH_PLAN.md, ENVIRONMENT_ANALYSIS_23.md i prethodni pregled literature. Nema novih terenskih mjerenja ili obavezne studije učesnika.

Autori: doc. dr. Semir Poturak; prof. dr. Amra Tuzović. University of Travnik, Faculty of Technical Sciences.

## Naslov i centralno pitanje

**SportSpace: višekriterijska analiza dostupnosti rekreacije uz prostorni okoliš i vremenski kontekst kvaliteta zraka — pilot Ilidža–Stup.**

EN: **SportSpace: Multi-Criteria Analysis of Recreation Accessibility with Spatial Environmental and Temporal Air-Quality Context — An Ilidža–Stup Pilot.**

Pitanje: kako se modelovani skupovi mogućih odredišta i poređenja termina rekreacije mijenjaju u zavisnosti od mrežne dostupnosti, vegetacije, vode i raspoloživog vremenskog konteksta zraka i meteorologije, i koliko su ti izbori stabilni na promjenu pretpostavki i rezolucije podataka?

Vrsta rada: primijenjeni računski metod i ponovljiva studija slučaja sa sekundarnim podacima. Doprinos je postupak povezivanja podataka različite prostorne i vremenske potpore, analiza kompromisa i granica odluke. Ne tvrditi novi algoritam, prvenstvo, dokaz zdravstvene koristi, ponašanje građana ili validiran digitalni blizanac. Poboljšana korisnost interfejsa ostaje hipoteza bez studije korisnika.

## Šta je već u pilotu

12 odredišta, 20 sintetičkih polazišta, 240 parova / 228 izračunatih mrežnih veza; jedno polazište bez ruta. WorldCover 2021: vegetacija i voda u 100/300/500 m; blizina vegetacije uz postojeće putanje u 25/50 m. CAMS/Open-Meteo 2021: 8760 sati, jedna regionalna ćelija. OSM snimak 2026. Godine se ne mogu predstavljati kao istovremeno opažen grad. Postojeća mreža predstavlja fiksni scenarij na kojem se ispituje historijski vremenski kontekst.

Nalaz 5/19 promjena najbližeg odredišta pravolinijski/mrežno je postojeći rezultat miješanih aktivnosti, ne rezultat za populaciju. Novu analizu raditi po vrsti aktivnosti; grupu sa jednim odredištem ne predstavljati kao smisleno rangiranje. 223 satelitska zelena kandidata ostaju dodatak o podacima, bez potvrđenih ulaza i bez automatskog dodavanja u mrežni model.

## Minimalni dodatak, bez širenja projekta

1. **Stanice i posljednja mjerenja:** imenovane tačke sa operatorom, koordinatama i njihovim izvorom, polutantom, jedinicom, vremenom mjerenja/objave/preuzimanja, statusom validacije i prazninama. FHMZ navodi automatske satne podatke kao nevalidirane [S1]. Ne interpolirati stanicu u svaki park. Ažurnost stranice nije ažurnost mjerenja.
2. **Historijski vremenski kontekst:** zadržati 2021 kao osnovni modelirani godišnji prozor jer CAMS niz već postoji; pribaviti ERA5 temperaturu, relativnu vlažnost, padavine, vjetar 10 m i zračenje sa imenovanim modelom, vraćenom ćelijom i UTC vremenom [S2]. To je jednogodišnji meteorološki opis, ne dokaz klimatskog trenda. Lokalna stanična analiza je dodatak samo za stvarno dostupne vremenski usklađene nizove i potvrđenu upotrebu.
3. **Poređenje mjesta i termina:** postojeća dostupnost + vegetacijski kompromisi; zaseban izbor datuma/sata i trajanja boravka. Regionalni zrak i meteorologija prvo određuju vremenski kontekst svih lokalnih opcija, a ne izmišljene razlike između susjednih mjesta.

Tri režima moraju biti jasno odvojena: posljednje opažanje; historijski model/reprodukcija; prognoza (ako se kasnije uključi). Prognoza nije neophodna za ovaj rad. Stanice nisu još integrisane, meteorologija još nije preuzeta, a uslovi stanične redistribucije nisu potvrđeni. Do tada citirani izvor/link i dokumentovan status zamjenjuju automatsko objavljivanje baze. Javna čitljivost ne dokazuje licencu baze; nije utvrđeno da je korištenje zabranjeno.

## Modeli i pravilo odluke

Za svaku aktivnost zasebno prikazati vektor: vrijeme puta (min), vegetacija uz put (% dužine u blizini klasifikovanih ćelija), vegetacija oko odredišta (%), voda oko odredišta (%) i kontekst zraka/vremena. Voda ostaje opisni kriterij ili korisnička preferencija, ne automatski zdravstveni bonus. Upotrijebiti postojeće najbliže/kumulativno/potencijalno mjerenje dostupnosti i Pareto skup za minimizaciju vremena i maksimizaciju vegetacije. Već poznate porodice modela nisu naša novina [S3].

Obavezni deskriptivni pokazatelj E3 za polutant p: E_p(r,t,d)=integral C_p(x(u),t+u) du kroz odlazak, fiksni boravak d i povratak. Jedinica µg·min/m³. To je integral koncentracije kroz vrijeme pod pretpostavkama, ne udahnuta doza, individualna izloženost ili zdravstveni rizik. Bez prostornog polja koristi se imenovani regionalni niz i rezultat nosi oznaku zajedničkog regionalnog scenarija. Povratna ruta se računa ili izričito pretpostavlja ista; ne nazivati dva puta jednosmjerni račun izmjerenim povratkom. Satni niz integrisati po komadima konstantnim intervalima uz dokumentovanu vremensku semantiku.

**Negativna kontrola:** kada sve opcije dijele isti nenegativni C(t), isti polazak i isti boravak, te se porede ugniježđeni vremenski intervali bez prostorne razlike, duža opcija ne može dobiti manji integral samo zato što je zelenija. Promjena termina može promijeniti integral; prostorno razlikovanje zahtijeva opravdano različite koncentracije. Podatak zajednički svim mjestima ne može se proizvoljno pretvoriti u lokalni rang. Za zajednički C(t), rang po E ne može preokrenuti rang po ukupnom trajanju pod tim uslovima. Prag E ili kombinovani kriterij može promijeniti skup mjesta, ali tada je razlika posljedica trajanja i pravila odluke, ne dokazanog lokalno čistijeg zraka.

Vjetar: ruža učestalosti i koncentracije po smjeru/brzini mogu opisati povezanost uz pokrivenost binova [S4]. Modelirani regionalni vjetar uz stanični zrak označiti kao miješanu prostornu potporu, ne lokalno strujanje. Nema pripisivanja izvora emisije iz same ruže. Bez emisija, meteorološkog profila, pouzdane geometrije i validacije ne pokretati CFD/AERMOD kao dokaz lokalne koncentracije [S5]. 3D stabla i procijenjene visine zgrada u interfejsu nisu ulaz spreman za taj račun.

UTCI: ne uvoditi dok nisu opravdani srednja radijantna temperatura, temperatura zraka, vlažnost i vjetar i provjeren domen aproksimacije [S6]. Regionalni osjećaj temperature može biti kontekst; nije hlad konkretnog parka. Geometrija vode ne daje automatski hlađenje niti kvalitet vode. Zelenilo ne znači nužno manje uličnog zagađenja [S7].

## Računski eksperimenti koje rad treba da sadrži

| Eksperiment | Poređenje i izlaz | Status |
|---|---|---|
| E1 Prostorni izbor | pravolinijski naspram mrežnog; po aktivnosti; promjene prvog izbora i dodatni minuti | postojeća osnova, novo grupisanje tek izvršiti |
| E2 Kompromis i osjetljivost | vrijeme 10/20/30 min; radijusi 100/300/500 m; zelenilo 10/20/30%; potencijal h=10/15/30; Pareto članstvo i veličina skupa | novi potpuni izvoz tek izvršiti |
| E3 Vremenski kontekst | svi potpuni dani 2021, termini 08/14/18 lokalno, boravak 30 min; scenariji 15/60 min kao osjetljivost; prikaz promjene E i meteo uslova, bez univerzalnog pobjednika | plan, meteorologija i račun nedostaju |
| E4 Potpora podataka | zajednička ćelija naspram stanične tačke, praznine, zakašnjela mjerenja; negativna kontrola da regionalni zrak ne stvara lokalni gradijent | plan provjere |

Ovo je datirani računski protokol, ne preregistracija. Scenariji su istraživačke postavke; ne birati naknadno samo dane koji daju zanimljiv rezultat. Za mjesečne/sezonske obrasce treba cjelovit godišnji prozor i prikaz pokrivenosti. Kratki stanični niz prikazuje samo taj prozor. Za stanične dnevne opise predložena kapija je >=75% validnih od stvarnog broja satnih UTC intervala lokalnog dana, uz osjetljivost na 90%; to je naša analitička postavka, ne tvrdnja o propisu. Ljetno računanje vremena rješavati UTC intervalima i stvarnim brojem sati u lokalnom danu. Praznine ne popunjavati nulom.

Ne tretirati 240 veza kao 240 nezavisnih ljudi, niti 8760 sati kao nezavisne replikacije. Primarno deskriptivna studija fiksnog obuhvata: imenilac, medijana/rasponi, razlike i osjetljivost. Bez p-vrijednosti za stanovništvo iz sintetičkih polazišta. Ako se kasnije uvede regresija PM–meteo, sezona i autokorelacija traže vremenski blokiranu provjeru; to nije potrebno za ovaj pilot. CAMS može asimilirati stanična opažanja [S8], pa stanicu ne nazivati nezavisnom validacijom bez provjere tačnog arhivskog proizvoda i asimilacionog skupa.

## Otvorena pitanja i izlaz ako ostanu neriješena

| Nepoznato | Potrebna provjera | Uži izlaz |
|---|---|---|
| stanična licenca/API/arhivska dostupnost | dokumentovan endpoint, uslovi i stvarna serija | citirati izvještaj/link; ne distribuirati bazu |
| EEA pokrivenost Ilidže | postoji servis [S9], ali tačna lokalna stanica/godina još nije potvrđena | ne obećavati EEA arhiv |
| koordinata, tip i promjene stanice | operatorov metapodatak, datum važenja | bez preciznog mapiranja i prostornog pridruživanja |
| vrijeme, validacija i pokrivenost | UTC/offset, flags, duplikati, revizije | vremenski niz sa jasno označenim ograničenjima |
| lokalne razlike zraka/vjetra | prikladna rezolucija i validacija | zajednički vremenski kontekst bez lokalnog ranga |
| stvarni ulaz i javni pristup | dokumentarni status | modelovane mogućnosti, ne obećanje pristupa |

## Beops — usko preuzete lekcije

Read-only pregled README.md, research/02-senses/SENSES_CONTEXT_MAP_2026-09-06.md i research/04-bibliography/LITERATURE_ENVIRONMENT_2026-09-06.md. Posljednji dokument nosi historical/superseded oznaku: služi kao trag literature, ne kao današnja potvrda feeda. Preuzeti tri vremena, null za nepoznato, odvojene mjerne/modelirane/prognozne kanale, hash izvoda i zasebnu provjeru licence članka i baze. Dokumentovana lekcija o dva prikaza iste stanice sprečava lažnu nezavisnu potvrdu. Ne prenositi beogradske vrijednosti, kalibracione koeficijente, rasporede kolektora, autore ili širu observatoriju. Beops nije mijenjan.

## Literatura i evidencija pretrage

Ciljani dopunski pregled, ne sistematski pregled i ne dokaz iscrpnosti/novine. Provjereno 20.09.2026 kroz javnu web pretragu i primarne stranice. Grane: lokalni operator/arhiva/licenca; pollution-aware routing; regionalna meteorologija; wind-concentration analiza; vizualizacija; protivdokazi za zelenilo=čist zrak. Upiti uključuju `Sarajevo kvalitet zraka Ilidža historijski podaci`, `air pollution route choice multi objective least exposure shortest route`, `historical weather ERA5 wind`, `openair polarPlot`, `UTCI operational procedure`, `FHMZ korištenje podataka`.

| ID | Primarni izvor / nivo čitanja | Potpora i granica |
|---|---|---|
| S1 | [FHMZ metodologija](https://www.fhmzbih.gov.ba/latinica/ZRAK/AQI-metodologija.php), otvorena stranica | satno ažuriranje, automatski nevalidirani podaci; verzionisati šemu indeksa, ne miješati 0–500 i 1–6 prikaze |
| S2 | [Open-Meteo historical weather](https://open-meteo.com/en/docs/historical-weather-api), dokumentacija | ERA5/ERA5-Land/IFS imaju različitu rezoluciju i varijable; ne koristiti auto izbor modela za nekontrolisani vremenski trend |
| S3 | Geurs & van Wee (2004), [DOI](https://doi.org/10.1016/j.jtrangeo.2003.10.005), postojeći pregled + bibliografska provjera; direktni publisher open nije uspio | porodice dostupnosti; detaljne tvrdnje provjeriti u punom tekstu prije finalne predaje |
| S4 | [openair polarPlot](https://openair-project.github.io/openair/reference/polarPlot.html) i [polar frequencies](https://openair-project.github.io/book/sections/directional-analysis/polar-freq.html), polarPlot dokumentacija otvorena; polarFreq indeksirani odjeljak | opis zajedničke raspodjele vjetra/koncentracije; bez nove biblioteke, bez tvrdnje da smo implementirali njihov smoothing |
| S5 | [EPA AERMOD formulation](https://nepis.epa.gov/Exe/ZyPURL.cgi?Dockey=P101CLHZ.TXT), indeksirani primarni odjeljci | fizički model sa zahtjevima za ulaze; nije odabran za pilot |
| S6 | [UTCI calculator](https://utci.org/utci_calc.php), otvorena specifikacija | zahtijeva radijantnu temperaturu i ostale ulaze; navedeni opseg vjetra 0.5–17 m/s |
| S7 | Venter et al. (2024), [NILU autorski zapis](https://nilu.no/publikasjon/2238204/), otvoren sažetak; [DOI](https://doi.org/10.1073/pnas.2306200121) | uticaj zelenila zavisi od skale i aerodinamike; ne preslikavati efekat na Ilidžu. PMC direktno blokiran browser provjerom |
| S8 | [CAMS European forecasts](https://ads.atmosphere.copernicus.eu/datasets/cams-europe-air-quality-forecasts?tab=overview), dokumentacija | 0.1° (~10 km), satni izlaz i asimilacija; ovo ne identifikuje podtip našeg arhiva 2021 |
| S9 | [EEA download service](https://www.eea.europa.eu/en/datahub/datahubitem-view/778ef9f5-6293-4846-badd-56a29c70880d), katalog | postoje verified/UTD servisi; lokalna pokrivenost i API odgovor još nisu provjereni; ArcGIS otvaranje nije uspjelo |
| S10 | Yan et al., Breathing Green, [puni autorski tekst v4](https://arxiv.org/html/2307.15401v4), sekcije algoritma/podataka pročitane, IEEE ITSC 2023 DOI 10.1109/ITSC57777.2023.10421940 | pollution-aware routing već postoji; Dublin ima street-by-street mobilna mjerenja. Njihov rezultat ne prenositi na naše ulaze |
| S11 | Tainio et al. (2016), [autorski PDF](https://www.pure.ed.ac.uk/ws/files/25193493/Tainio_2016.pdf), metode pročitane | dugoročni scenariji i ventilacija/doza; nije pravilo za individualni današnji izlazak |
| S12 | Munzner (2009), [autorski zapis](https://www.cs.ubc.ca/labs/imager/tr/2009/NestedModel/), sažetak | odvojiti domenski zadatak, podatke, vizuelno kodiranje i algoritam; UI test nije evaluacija korisnosti |
| S13 | [Ilidža satna tabela](https://www.fhmzbih.gov.ba/latinica/ZRAK/amsIlidza.php), otvorena tabela 14–19.09.2026 | opažena dostupnost kratkog prozora, ne garancija živog feeda ili godišnje arhive |
| S14 | [ZZJZKS izvještaj 2021](https://zzjzks.ba/wp-content/uploads/2022/11/Izvjestaj-o-monitoringu-kvaliteta-zraka-u-Kantonu-Sarajevo-za-2021.pdf), indeksiran sadržaj, direktni PDF open greška | trag za vremenski usklađenu provjeru; tabelarni brojevi nisu preuzeti niti potvrđeni u ovom prolazu |

## Struktura rada i figure

Uvod i precizan problem → povezani radovi → podaci/potpora/licence → dostupnost i višekriterijski postupak → računski eksperimenti → rezultati i osjetljivost → ograničenja i ponovljivost. Četiri glavne figure: (1) obuhvat i prostorna potpora izvora; (2) put–zelenilo/Pareto; (3) kalendar satnih uslova i pokrivenosti; (4) stabilnost izbora prema parametrima. 2D/3D prikaz instrumenta može biti jedna manja ilustracija. Ne širiti rad na evaluaciju 3D, CFD, AI, buku ili zdravstveni efekat.

Pošten zaključak: imamo izvodljiv, ograničen metodski rad. Postojeći proračuni su osnova; nova meteorološka i stanična komponenta i kompletni eksperimenti su otvoren posao. Konačan zaključak može biti i negativan: dostupna rezolucija ne opravdava različit zrak za susjedna odredišta. To je rezultat o granicama odluke, ne razlog da proizvodimo lažnu preciznost.

## Ispravka kontinuiteta
Raniji ENVIRONMENT_ANALYSIS_23.md već bilježi radni prepis Ilidža 2024 i isključenje iz javnog paketa zbog nepotvrđene licence baze. Zato prethodnu razgovornu formulaciju da stanice ranije nisu provjerene treba suziti: postojalo je izviđanje, ali nije završena integracija, vremenska analiza ni potvrda uslova redistribucije. Ovaj pregled proširuje taj trag; ne počinje od nule.

## Razriješen metodološki pregled, 20.09.2026
Odvojeni reviewer pročitao je plan i provjerio Open-Meteo dokumentaciju i Breathing Green; nije izvršavao nove račune ili provjeru licenci stanica. Prihvaćene korekcije:

- Predmet su modelovani skupovi i poređenja, ne stvarno ponašanje ljudi.
- Za regionalni slučaj: T_r = tau_odlazak,r + d + tau_povratak,r; E_p(r,t,d) = integral od 0 do T_r C_p(t+u) du. Ista regionalna koncentracija važi za put i boravak; unutrašnji prostor nije modeliran. E je obavezni deskriptivni izlaz E3, odvojeno po PM2.5, PM10, NO2 i O3; ne sabiraju se polutanti.
- E3 poredi 08/14/18 Europe/Sarajevo unutar istog datuma i istog para polazište–odredište. Imenilac po polutantu čine samo potpuni upareni scenariji, s podacima za cijeli izlet, uključujući prelazak dana; izlazak van godišnjeg izvoda se izostavlja i broji. Prikazati uparene razlike E i broj važećih parova; meteorologija ostaje paralelan kontekst. Satni prosjek zračenja prethodnog sata nije trenutna vrijednost: semantiku navesti po varijabli.
- E4 poredi numeričke stanične i regionalne vrijednosti samo kad postoji vremenski usklađena arhiva. U suprotnom završava auditom potpore/metapodataka i negativnim kontrolama; stanica nije uslov da se završi rad.
- Potencijal P_i(h)=sum_j 2^(-t_ij/h), h u minutama. Prag zelenila E2 odnosi se na udio vegetacijskih klasa u odredišnom bufferu izabranog radijusa; koridor je zaseban indikator. Rangiranje koristi punu preciznost; praktične jednakosti definisati tolerancijom 10^-9 u jedinici indikatora i zadržati sve vezane alternative. Pareto dominacija traži barem jedan strogo bolji kriterij izvan tolerancije.

Ove dopune su razrješenje pregleda; ne označavaju eksperimente kao izvršene.

## Izvršenje20.09.2026
Plan E1/E2/E3 je sada izvršen; E4 numeričke kontrole i dokumentarni audit su izvršeni, stanična numerička validacija nije. Važeći rezultati i granice: RESULTS_25.md i STATION_AUDIT_25.md. Oznake NOT_RUN u ranijem planu opisuju vrijeme definisanja protokola; ne prepisuju ovaj datirani rezultat.
