# SportSpace v0.29 — konačna lokalna predaja

Datum: 20.09.2026.  
Status: **spremno za autorski pregled i predaju; nije javno objavljeno niti poslano konferenciji**.

## Završni rezultat

- `SportSpace_ICSIE_2026_FINAL.docx`: konačni rad u službenoj ICSIE strukturi, 13 A4 stranica, 4 tabele i 4 figure.
- `MANUSCRIPT_ICSIE_FINAL.md`: uređivački izvor istog rada.
- `release/SportSpace_ICSIE_2026_submission.zip`: verzionisani analitički i softverski prilog.
- `release/SportSpace_ICSIE_2026_submission.sha256`: kontrolni hash arhiva.
- `review/final/verification.json`: mašinski čitljiv završni zapis provjere.

DOCX SHA-256: `2cbcaa4de42108e46987e58f1e2e89740196822d0255c82719c89e29842feeab`  
MD SHA-256: `6b439b934156764a6941774773c4638412e32b8a7745ac53b8214498f0648193`

## Šta je provjereno

Svih 11 projektnih testova prolazi u konačnom stanju. Provjere obuhvataju hronologiju i agregaciju podataka o zraku, rekonstrukciju WorldCover rastera, odredišne radijuse i putanje, izdvajanje zelenih kandidata, modele dostupnosti, scenarije planiranja, naučne izlaze, BS/EN/TR interfejs, 2D/3D, mobilni raspored, CSV izvoz, reduced-motion i WebGL fallback.

DOCX je renderovan na 13 A4 stranica i svaka stranica je vizuelno pregledana. Nisu pronađeni preklopi, odsječeni sadržaj, oštećene tabele ili figure. Audit pristupačnosti dokumenta nema nalaze visokog, srednjeg ili niskog nivoa.

## Doprinos rada

Rad pokazuje kako jedan ograničeni urbani pilot može povezati modelovano pješačko vrijeme, sportska i rekreacijska odredišta, vegetaciju, vodu i regionalne vremenske profile zraka bez izmišljanja jedinstvenog zdravstvenog skora. Najkraće odredište, broj mogućnosti, potencijal dostupnosti, zajednički prag vremena i vegetacije te vremenski profil izloženosti odgovaraju na različita pitanja i ostaju odvojeni pokazatelji.

## Granice tvrdnji

Polazišta su sintetička i ne predstavljaju stanovništvo. OSM mreža je snimak iz 2026, a WorldCover, CAMS i ERA5 kontekst iz 2021. Bazni graf je ponovljiv, ali pješačka semantika smjerova i topologije nije terenski potvrđena. Rad ne tvrdi izmjerene zdravstvene efekte, ponašanje, trenutnu otvorenost, lokalnu disperziju, buku ili podatke uživo. Stanična validacija, terenska provjera i studija korisnika pripadaju budućem radu.

## Honest verdict

**Provjereno:** analitički izlazi, hashovi, figure, finalni DOCX, format, lokalni pilot i cijeli testni skup.  
**Zaključeno u okviru modela:** izbor odredišta i rezultati osjetljivosti za sačuvane sekundarne podatke i navedene parametre.  
**Nije provjereno:** stvarno ponašanje građana, zdravstveni učinak, kvalitativna upotrebljivost sa učesnicima, stanje terena i lokalni zrak u realnom vremenu.
