# SportSpace — naučni rezultati v0.25

20.09.2026 · doc. dr. Semir Poturak; prof. dr. Amra Tuzović
University of Travnik, Faculty of Technical Sciences

Status: izvršena računska studija postojećeg pilota. UI nije mijenjan. Ovo je rezultat/metodski materijal za članak, ne konačan rukopis ili tvrdnja da je spreman za predaju.

## Glavni nalaz

Najbliže odredište zavisi od načina mjerenja puta. Skup kompromisnih opcija zavisi i od radijusa kojim opisujemo zelenilo. Termin mijenja modelirani integral koncentracije kroz vrijeme, ali različiti polutanti ne daju isti vremenski poredak. Podaci zato podržavaju višekriterijsko poređenje uz granice potpore, a ne univerzalni zdravstveni skor.

## Podaci

Fiksni OSM model2026, WorldCover2021, CAMS2021 (ćelija18.3E/43.8N) i ERA5/Open-Meteo2021 (vraćena ćelija18.25E/43.75N). ERA5 je eksplicitno odabran; 8760 UTC sati za svih šest parametara, provjerene jedinice, redoslijed i osnovni fizički opsezi. Različite ćelije nisu nezavisna lokalna mjerenja. Meteorologija: temperatura, relativna vlažnost, padavine, brzina/smjer vjetra na10m i kratkotalasno zračenje.

Regionalna godišnja analiza koristi UTC godinu; lokalni mjesečni/satni prikaz ima8759 sati jer izvod ne sadrži00h lokalno1.januara2021. Datirani polasci08/14/18 imaju potpunu pokrivenost svih365 datuma i cijelog izleta. Padavine/zračenje opisuju prethodni sat; ostali meteo parametri trenutak oznake prema API dokumentaciji.

## E1 — posljedica izbora mjere udaljenosti

| Aktivnost | Odredišta | Rutabilna polazišta | Promjena najbližeg | Dodatni minuti do pravolinijski najbližeg, maksimum |
|---|---:|---:|---:|---:|
| Sve aktivnosti (opisno) | 12 | 19/20 | 5/19 | 6.67 |
| Sportski teren | 1 | 19/20 | 0/19 | 0.00 |
| Igrališta | 8 | 19/20 | 4/19 | 5.02 |
| Sportski centri | 3 | 19/20 | 3/19 | 9.98 |

Dodatni minuti = mrežno vrijeme do najboljeg među vezanim pravolinijski najbližim odredištima minus minimalno mrežno vrijeme iste aktivnosti. Mrežno vrijeme se računa iz objavljene dužine (preciznost0.1m) i1.2m/s, umjesto već zaokruženih minuta. Jedno polazište nema rute: nepoznato, ne nula. Sportski teren ima jednu opciju pa njegova nulta promjena nije dokaz stabilnosti konkurentskih alternativa. Sintetička polazišta nisu stanovništvo.

## E2 — kriteriji i osjetljivost

1620 redova parametara:20polazišta×3aktivnosti×3radijusa×3vremenska praga×3praga zelenila. Od toga1539 redova imaju rutabilno polazište,81 nepoznato. Potencijal h=10/15/30min sačuvan je za svaki red; to nisu dodatne nezavisne opservacije.

| Aktivnost | Promjena Pareto skupa između100 i500m | Imenilac |
|---|---:|---:|
| Sportski teren | 0 | 57 |
| Igrališta | 20 | 57 |
| Sportski centri | 0 | 57 |

Imenilac57=19rutabilnih polazišta×3vremenska praga; prazni skupovi su uključeni. Pareto poredi manje minuta i više vegetacije, prije primjene korisničkog praga zelenila. Zajednički uslov vremena/zelenila je zasebno izvezen kao joint_count/joint_ids. Voda je opisni prosjek oko prihvatljivih odredišta, bez zdravstvene težine.

Procenti su ponovo izvedeni iz rastera bez zaokruživanja; numerička razlika od milionitih procentnog poena ne dokazuje ekološki značaj. Dodatni račun precision-sensitivity.json provjerava promjenu pri zaokruživanju zelenila na0.001 i1procentni poen; to je analiza osjetljivosti, ne izmjerena nesigurnost rastera.

## E3 — isti izlet, tri termina

Osnovni boravak30min, isti pretpostavljeni povratak kao odlazak, polasci08/14/18 Europe/Sarajevo. Za svaki polutant83.220 uparenih slučajeva=228veza×365datuma; to nije83.220nezavisnih mjerenja ili ljudi. Svaki slučaj koristi isti regionalni niz. Svi parovi imaju iste težine; rezultat nije ponderisan populacijom.

Integral E ima jedinicuµg·min/m³; nije udahnuta doza. Tabela prikazuje medijanu uparene razlike14h−08h i udio scenarija u kojima je14h strogo najmanji E među tri termina.

| Polutant | Medijana E14−E08 | 14h ima najmanji integral (%) | Vezani minimumi |
|---|---:|---:|---:|
| PM₂.₅ | -401.35 | 72.86 | 72 |
| PM₁₀ | -224.75 | 44.75 | 24 |
| NO₂ | -439.57 | 78.44 | 120 |
| O₃ | 2389.75 | 0.55 | 347 |

Ovo opisuje godišnji regionalni scenarij2021, ne preporuku za danas. PM i NO₂ u ovim scenarijima često favorizuju14h; O₃ daje drugačiji kompromis. Poređenja boravka15/60min nalaze se u e3-temporal.json. Datirani meteo kontekst1095polazaka u regional-departures.json omogućava povezivanje s konkretnim uslovima. Meteo trenutno nije uključena u zbirni rang; nema tvrdnje o termalnom komforu duž puta.

## E4 — granice i kontrole

4380provjera ugniježđenih intervala (4polutanta×365dana×3termina), bez kršenja monotonosti nenegativnog integrala. Jedna regionalna ćelija ne proizvodi prostorni gradijent. Duža putanja pri istom polasku i boravku ne dobija manji E zbog zelenila; promjene složenog izbora zahtijevaju eksplicitna pravila i tumačenje trajanja.

Provjereni su null, stvarna nula, djelimični sat i granica arhive. Sve80E1kombinacije,1620E2redova i nezavisna PM₂.₅integracija svih228ruta prolaze regresiju. Meteorološki sektori i tišina čine tačnu particiju8760sati. Ruže prikazuju povezanost modeliranog vjetra i modeliranog zraka, ne izvor emisije.

## Stanice — dokumentarna provjera, bez lažne validacije

[Poseban audit](STATION_AUDIT_25.md) čuva šta je pronađeno i šta ostaje nepoznato. Nije uspostavljen ovlašten, vremenski usklađen satni niz za numeričku provjeru CAMS2021. Zbog toga nije izračunata stanična greška modela niti napravljena lokalna interpolacija. Ovo ograničava domet, ali ne blokira opisanu modeliranu studiju.

## Ponovljivost i dokazi

Iz korijena SportSpace: `node tools/science-v025.cjs`, zatim `node tests/science-v025.test.cjs`. Nema mreže ni dodatnih npm biblioteka u računu. Nabavka je zasebna: `node tools/weather-acquire-v025.cjs`; keš se provjerava prema manifestu.

Deset analitičkih izlaza proizvedeno je dva puta s identičnim SHA256; manifest generisanja je izuzet jer sadrži vrijeme. Ulazni hash-evi i verzija skripte su u summary.json i manifest.json. Izvori i licence ostaju po datasetu (OSM/ODbL, WorldCover/CCBY4, Open-Meteo/Copernicus uz atribuciju). Stanične baze nisu dodate javnom paketu.

Dokazi: data/processed/science/v025/; review/v025/science-qa.json; review/v025/reproduction.json.

## Honest verdict

Provereno: izvršavanje modela, vremensko uparivanje, jedinice, obuhvat, nezavisni numerički računi, odvojeni pregled i offline reprodukcija. Zaključeno: opisani kompromisi važe za ove podatke i pretpostavke. Nije provereno: stvarno ponašanje, zdravstveni učinak, stvarna prohodnost svih ruta, lokalna disperzija i kvalitet predikcije prema nezavisnim stanicama. Nisu objavljeni nova aplikacija ili rad.

## Dopunska provjera numeričke osjetljivosti

Za korak 0.001procentnih poena promijenjeno je 3/513 frontova (bez ponavljanja za tri praga zelenila). Kod igrališta promjena radijusa100→500m daje 20/57 promjena. Vrijeme nije zaokruživano u ovom poređenju.

Za korak 1procentnih poena promijenjeno je 17/513 frontova (bez ponavljanja za tri praga zelenila). Kod igrališta promjena radijusa100→500m daje 19/57 promjena. Vrijeme nije zaokruživano u ovom poređenju.


Dopunski račun se ponavlja komandom `node tools/precision-sensitivity-v025.cjs`; njegov zaseban hash i provjera ponavljanja su u review/v025/precision-reproduction.json. Deset osnovnih izlaza i ovaj dodatni izlaz imaju odvojene provjere.
