# SportSpace — provjera smisla indikatora i urbanističko usmjerenje

20.09.2026. Ovo je ciljana opsežna provjera postojećeg pilota i rukopisa, a ne sistematski pregled cjelokupne literature. Prethodni računi nisu prepisani novim pretpostavkama. Nema novih terenskih mjerenja, učesnika, izmjena aplikacije ili objave.

## Nova okosnica

**SportSpace: prostorni dokazi za planiranje urbanih sredina koje podržavaju aktivnost — pilot Ilidža–Stup.**

Predmet je preliminarno razmatranje uslova za sport, rekreaciju i fizičku aktivnost. Urbanizam daje pitanja o rasporedu i povezanosti; urbani i pejzažni dizajn o putu i ambijentu; fizičko vaspitanje i sportska praksa o stvarnoj prikladnosti prostora za određenu aktivnost i grupu; javno zdravlje daje motivaciju. Podaci ovog pilota pokrivaju samo dio tih pitanja.

Lanac tumačenja: **izvor → pokazatelj → pitanje → dozvoljena preliminarna radnja → nedostajući dokaz**. To je predloženi način upotrebe, ne evaluirana korisnost. Nema dokaza da bolji broj automatski znači bolju participaciju ili zdravlje.

## Provjera po domenima

| Domen | Šta imamo | Nalaz provjere | Posljedica za rad |
|---|---|---|---|
| Prostorni uzorak |20sintetičkihcentara,4×5,tehničkiobuhvat |nije uzorak stanovnika niti cjelovit inventar okoline |bez procjene potreba,nepravednosti ili prioriteta ulaganja |
| Konstrukcija mreže |OSMnačinfiltriranja,usmjerenost,čvorovipozaokruženimkoordinatama |vozilskajednosmjernost prenesena u graf; topološki identitet izvornog čvora nije očuvan |nalazi važe za baznu reprezentaciju; potrebno suziti pešačko tumačenje |
| Numerička reprodukcija |240izvezenihparova,228ruta |nezavisno rerutiranje reprodukuje sve dužine,0neslaganja |račun reproduktivan; to nije fizička validacija mreže |
| Smernaosjetljivost |isti graf sa simetrizovanim vezama |125/228kraćihveza;max11.45min;1/19promijenjen najbliži centar |nije potvrđen stvarni dobitak vremena; scenarij reprezentacije |
| Priključci |pravolinijski do najbližeg čvora |medijana udjela2.13%,maksimum13.94%;polazišta9.6–138.3m,odredišta6.0–38.2m |priključak nije dokazana prohodna staza ili ulaz |
| Nerutirano polazište |jedno polazište bez12ruta |svih20polazišta zadovoljava350mprag |nije uzrok prekoračenje praga; stvarni lokalni razlog nije utvrđen |
| Identitet kandidata |dvabliska para40.7/55m |grupisanje mijenja15/57brojeva prilika,najvišeza2 |8igrališnihzapisa nije8potvrđenihnezavisnihfunkcionalnihobjekata |
| Sport/DIF |OSMklaseobjekata |nema opreme,kapaciteta,uzrasneprikladnosti,dozvole,programa |početna lista za dokumentarnu provjeru,ne potvrđeno mjesto nastave/treninga |
| Vegetacija/voda |satelitskeklase i baferi |prostorni kontekst,ne kvalitetdizajna,hlad ili javnipristup |bez zdravstvenihtežina,hladenja ili automatskogprojektnogzahvata |
| Zrak/meteo |regionalnimodel2021,različitećelije |termini se mogu porediti;lokalnirang i današnjisigurantermin nisu izvedivi |E3ostaje historijskistandardizovaniscenarij |
| Izvještavanje |v0.25tabele,4figure,izvornimanifesti |nazivi,brojevi i jedinice ranijeprovjereni;novaauditosjetljivost ih uslovljava |jasno označiti baseline;nije ponovljen E2/E3zasvescenarije |
| Spoljna validacija |nema učesnika ni terenskihpotvrda;stanice dokumentarno |nije izvedena validacija zdravlja,ponašanja ili korisnosti |ostaje ograničen računskirad |

## Protokol dopunskog računa

Definisan prije izvršenja u ovoj reviziji: zadržati ulazni graf,nodove,dužine,snapovanje i skup kandidata; reprodukovati bazne vrijednosti; zatim dodati obrnutu vezu za svaku granu. Ne nazivati rezultat korigovanom pešačkom mrežom, jer se ne provjeravaju specifične footrestrikcije,prepreke,mostovi,slojevi ili čvorovni identitet. Vrijeme je dužina/72m/min. Za zapis kraćeveze pragrazlike>0.1m.

Za bliskepare: grupisati oba označena para u posebnom scenariju. Za svaki od19rutabilnihpolazišta i3vremenskapraga izračunati broj jedinstvenihgrupa sa barem jednim prihvatljivim članom. Potencijalni dopunski izvoz unutarpraga koristi najveću težinu člana; nije isti indikator kao nepragovani potencijalv0.25. Nisu spojene geometrije niti prosječeno zelenilo, i identitet nije proglašen riješenim.

Skript: tools/planning-audit-v027.cjs. Izlaz: data/processed/science/v027/planning-network-audit.json. U izlazu su izvornihash-evi,skripthash,sviparovi,priključci,grupisanje i poređenje najbližih. Jedinični primjerDijkstre i monotoni uslov proširenjagrafa prolaze; nezavisni sadržajni pregled bilježi konkretna ograničenja.

## Književnost i nivo potpore

Primarne stranice otvorene20.09.2026:

- WHO2018, Global action plan on physical activity2018–2030: https://www.who.int/publications/i/item/9789241514187 . Otvoren službeni pregled; puniPDF vraća403. Potpora: višesektorski okvir fizičke aktivnosti i okruženja; ne lokalni prag ili efekat.
- WHO2020, Integrating health in urban and territorial planning: https://www.who.int/publications/i/item/9789240003170 . Otvoren pregled; izričito kontekstualni procesi i alati, ne univerzalni recept.
- WHOEurope2016, Urban green spaces and health: https://www.who.int/europe/publications/i/item/WHO-EURO-2016-3352-43111-60341 . Otvoren pregled; putevi povezanosti uključuju aktivnost i obnovu; nema prenosa efekta na lokalne baferprocenate.
- Boeing etal2022: https://arxiv.org/abs/2205.05240 . Otvoren autorski sažetak;PDF69MBprevelikzaalat. Relevantan prethodni rad o otvorenim prostornim indikatorima; nije detaljno prepričan niti proglašen punimčitanjem u novom rukopisu.
- OSM key:oneway: https://wiki.openstreetmap.org/wiki/Key:oneway i key:oneway:foot: https://wiki.openstreetmap.org/wiki/Key:oneway:foot . Otvorena izvorna dokumentacija semantike tagova; onewaynaulicama primarno vozilski,pešačkismjerzaseban. Nije zamjena za lokalni pravni/prohodni status.

Ranije pregledana literaturaGeurs,Venter,Yan,Munzner ostaje uz prethodne nivoe čitanja. Ovo nije iscrpna pretraga; nisu dodate tvrdnje o prvenstvu,novomalgoritmu ili kauzalnojkoristi.

## Mapa koja povezuje račun i prostor

Za unaprijed postojeći scenarijv0.25: igrališni kandidati,20minjednosmjerno,≥20%vegetacijeu300m. Na stvarnomWorldCoverpodlošku saOSMulicama brojevi u sintetičkim polazištima prikazuju joint_count. Nula je računati izostanak kandidata u ovom scenariju;?je nepoznato zbog rute. Nema interpolacije,izohrona,populacionepokrivenosti ili kontinualnog zdravstvenoggradijenta. Triangli razlikuju kandidate koji ispunjavaju vegetacijskiuslov; svi imaju neprovjeren pristup. Karte ne koriguju bazne mrežne pretpostavke.

## Honest verdict

Provereno: semantika postojećihindikatora,pravilaulaza,nezavisno rerutiranje,dijagnostičkausmjerenost,priključci,alternativnogrupisanje,primarnakonceptualnaliteratura,novousmjerenje i izvornevezenovemape. Zaključeno: najčvršćidoprinos je preliminarni prostornipregled za aktivneurbaneuslove i otkrivanje osjetljivihpretpostavki. Nije provereno: ispravljenapešačkatopologija,stvarneprepreke,identitetbliskihparova,učinakintervencija,današnjeokruženje ili koristpraktičnihodluka. Wordprelom i konačnapredaja ostaju otvoreni.
