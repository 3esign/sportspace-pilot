# SportSpace: Spatial Evidence for Planning Active Urban Environments in Ilidža–Stup

Semir POTURAK¹, Amra TUZOVIĆ²

¹ doc. dr. Semir Poturak, University of Travnik, Faculty of Technical Sciences. ORCID: https://orcid.org/0009-0004-1537-2074. E-mail: semir.poturak@eftfts.edu.ba.

² prof. dr. Amra Tuzović, University of Travnik, Faculty of Technical Sciences. E-mail: amra.tuzovic@eftfts.edu.ba.

## ABSTRACT

Urban planning and public-space design can support opportunities for sport and recreation, but mapped proximity alone does not establish usable access or health benefit. This study presents SportSpace as a preliminary spatial screening workflow linking recreation candidates, network accessibility, vegetation and historical environmental context in Ilidža–Stup. Twenty synthetic origins and twelve mapped candidates define 240 pairs, of which 228 are routable in the baseline model. Within activity categories, the workflow compares straight-line and network proximity, cumulative opportunities and travel-time–vegetation Pareto sets. Regional hourly data support separate pollutant-specific comparisons of three departure times across 2021. Network distance changes the nearest playground candidate for four of nineteen routable origins and the nearest sports-centre candidate for three. Changing vegetation buffers from 100 to 500 metres changes the playground Pareto set in twenty of fifty-seven cases. Paired temporal comparisons differ between particulate matter, nitrogen dioxide and ozone. An additional audit shows that removing directional restrictions shortens 125 modelled connections, while grouping two unresolved candidate pairs changes opportunity counts in fifteen of fifty-seven cases. These sensitivities make the quality of the spatial representation part of the planning finding. The indicators are linked to questions about route continuity, the spatial scale of green context and candidate review for recreation programmes, including physical education. They support structured preliminary investigation, not investment priorities, certified activity venues or safe exercise prescriptions. The contribution is a reproducible connection between calculation, planning question and evidence requirement, with explicit separation of modelled opportunity, actual participation and health outcomes.

Keywords: Active recreation; Environmental context; Spatial accessibility; Urban design; Urban planning

## 1. INTRODUCTION

Planning for an active city involves connecting places where people may play, exercise and participate in sport with the routes and environmental conditions through which those places are used. This connects urban planning, public-space design, physical education and public health. The World Health Organization (WHO, 2018) places active environments alongside other actions supporting physical activity, while its urban-planning sourcebook emphasises incorporating health into contextual planning processes rather than prescribing one solution for every setting (WHO, 2020).

For an early-stage planning assessment, a useful question is not simply whether a sports symbol or green area exists on a map. It is which mapped candidates merit closer examination, what effort the model assigns to reaching them, what surrounds them and which uncertainties could change the comparison. A recreation coordinator or physical-education professional additionally needs activity type, capacity, equipment, permission and suitability for the intended group. Spatial indicators can structure that inquiry even when they cannot answer all of it.

SportSpace examines how existing secondary data can support this preliminary screening in Ilidža–Stup. The central question is: how can modelled access, green context and historical environmental conditions be translated into transparent planning questions for sport and recreation without treating them as verified participation or health outcomes? The analytical subquestions concern proximity measured through a network, sensitivity to the spatial definition of vegetation, and differences between historical departure-time scenarios. Water and meteorology provide parallel descriptions.

The contribution is an applied, reproducible workflow connecting each indicator to an intended decision and the evidence needed before acting on it. Three distinctions organise the study: mapped candidate versus usable opportunity; modelled opportunity versus actual participation; and health-relevant spatial conditions versus demonstrated health effect. A contextual link between these levels motivates the study, but the levels are not estimated as a causal chain. The pilot introduces neither a new routing algorithm nor an evaluated planning intervention. Its contribution also includes diagnosing when the representation itself changes the apparent result.

## 2. LITERATURE REVIEW

Health-oriented urban planning provides the policy context for the analysis. WHO (2018, 2020) connects physical activity with environments and cross-sector planning, while the WHO Regional Office for Europe (2016) reviews several pathways linking green space and health, including physical activity and restoration. These sources motivate investigating spatial conditions; they do not supply a conversion from our vegetation percentages or walking minutes to a local health effect. In particular, accessible space, its functional quality and actual use remain distinct constructs.

Accessibility research distinguishes measures that answer different questions about opportunities and the effort required to reach them (Geurs & van Wee, 2004). A nearest-destination measure identifies one minimum, a cumulative measure counts opportunities within a threshold, and a distance-decay measure retains contributions from more distant opportunities with decreasing weight. SportSpace uses these established families as complementary descriptions. The numerical thresholds and decay settings are analytical scenarios, not empirically calibrated preferences of local residents.

Pollution-aware routing is also an established research direction. Yan et al. (2024) describe a Dublin application using large-scale street-level air-quality data to compare travel routes. Their study motivates examining environmental trade-offs, but its spatial information is materially different from a single regional time series. SportSpace therefore compares the timing and duration of outings under shared regional conditions; it does not reproduce street-level pollution routing or transfer reported benefits from another city.

Vegetation is kept separate from air quality. Venter et al. (2024) report that associations between urban green space and air pollution vary with scale and context, including street-level aerodynamic effects. A satellite vegetation percentage consequently cannot be treated as a fixed reduction factor for pollutant concentration. It is also not a direct measure of shade, public access, recreational quality or visible greenery. These distinctions are especially important when a detailed map could visually suggest local environmental certainty.

The visual interface is treated as an analytical instrument rather than a validated intervention. Munzner (2009) distinguishes domain and data characterisation, visual encoding and algorithmic implementation as different levels of design and validation. In this study, computational checks address the implementation and the reported indicators. They do not establish that citizens or planners make better decisions with the interface. That question remains suitable for subsequent user research.

## 3. METHODOLOGY

### 3.1 Study design and data support

The analytical unit is a modelled origin–destination pair or a specified parameter scenario, not a person. Twenty synthetic origins are paired with twelve mapped destination candidates: eight playground records, three sports-centre records and one sports-pitch record. All twelve pairs for one origin lack a modelled route, leaving 228 routed pairs and nineteen routable origins. Activity-specific analysis avoids treating these facilities as interchangeable. The single pitch provides a descriptive case without competing destinations in its category. Two unresolved close pairs among the playground records (55.0 and 40.7 m apart) are retained separately in the baseline; twelve records therefore do not establish twelve independent functional opportunities. The technical window is not an exhaustive destination inventory for residents, and candidates outside it can affect a real nearest-place comparison.

Origins are cell centres of a four-row by five-column grid within the technical work window [18.300° E, 43.828° N, 18.352° E, 43.850° N], not an administrative boundary. The baseline connects origins and destinations to graph nodes within a 350 m snapping limit; reported distances include both synthetic connectors. Included OSM ways tagged oneway=yes/1 or junction=roundabout are treated as directed, and other included ways as bidirectional. These baseline graph rules are not verified pedestrian restrictions. Consequently, the accessibility results are conditional on this network representation, including its directionality and unverified connectors.

Table 1. Data sources and their roles in the pilot

| Input | Temporal and spatial support | Analytical role | Principal limitation |
|---|---|---|---|
| OpenStreetMap network and destination extract | Fixed 2026 snapshot | Modelled walking distance and destination categories | Actual entrances, access and traversability are not field-verified |
| ESA WorldCover v200 | 2021 land cover, nominal 10 m cells | Vegetation and water around destinations | Classification and scale do not establish shade or public access |
| CAMS-derived Open-Meteo air archive | 8,760 UTC hours in 2021; returned location 18.3° E, 43.8° N | Shared PM2.5, PM10, NO2 and O3 time series | Cannot distinguish neighbouring routes; exact archive subtype remains unresolved |
| ERA5 through Open-Meteo | 8,760 UTC hours in 2021; returned location 18.25° E, 43.75° N | Temperature, humidity, precipitation, wind and radiation context | Regional model output, not street-level microclimate |
| Official Ilidža air-quality pages and reports | Documented station information and published summaries | Audit of available station evidence | No matched authorised hourly archive established for numerical validation |

The different source years are intentional components of a scenario: the fixed 2026 network is evaluated against 2021 land cover and environmental histories. They do not reconstruct a simultaneously observed city. Current provider documentation lists European CAMS reanalysis coverage from 2013, but the precise archived product lineage used by the saved response has not been established beyond its acquisition record (Open-Meteo, n.d.-a). ERA5 was explicitly selected rather than allowing automatic model selection. Its nominal grid spacing is 0.25°, and the API may apply elevation-related processing; returned coordinates and acquisition parameters are retained (Open-Meteo, n.d.-b). No station measurement is substituted for the regional series.

WorldCover vegetation comprises classes 10, 20, 30, 90, 95 and 100; cropland class 40 is separate and permanent water is class 80 (Zanaga et al., 2022). The analysis retains the original local raster extract. Each percentage divides the relevant class area by the area of all valid classified cells whose centres fall within the circular buffer, excluding nodata value 0. Cell areas are latitude-weighted on a sphere. Centre-to-centre distances use a local metric approximation anchored at 43.839° N. These are computational choices; the retained decimal precision does not imply equivalent physical accuracy.

![Figure 1](figures/v027/figure5-planning-map.png)

Figure 1. Spatial summary of the baseline screening scenario: playground candidates within 20 assumed walking minutes and with at least 20% vegetation in a 300 m destination buffer. Numbers apply only at synthetic origin points and count candidate records, including unresolved close pairs; they are not interpolated catchments or population coverage. Zero means no qualifying candidate in this model, while ? denotes a missing route. Filled triangles meet the vegetation condition; outlined triangles do not. Close markers can overlap. Background vegetation and water are satellite classes, not verified public spaces. The dashed frame is the technical work window. Thresholds are analytical settings, not health or planning standards; network and access limitations still apply.

### 3.2 Accessibility and destination trade-offs

For origin i and destination j, one-way walking time is t_ij = L_ij / 72, where L_ij is the exported network distance in metres and 72 metres per minute corresponds to the assumed walking speed of 1.2 m/s. Exported distances have 0.1 m precision. The analysis recalculates time from distance rather than using previously rounded display minutes. Route absence remains unknown, not zero accessibility.

Within each activity category, the nearest destination is evaluated separately under straight-line and network distance. Tied minima are retained. Additional time associated with selecting a straight-line nearest destination is the smallest network time among the tied straight-line minima minus the minimum network time in that category. This definition avoids penalising an arbitrary choice among equal straight-line alternatives.

For a time threshold τ, cumulative accessibility is N_i(τ) = Σ_j 1[t_ij ≤ τ]. Potential accessibility is P_i(h) = Σ_j 2^(−t_ij/h), where h is a half-decay time in minutes. The latter is a weighted opportunity count, not a probability or health index. The study evaluates τ = 10, 20 and 30 minutes and h = 10, 15 and 30 minutes. Destinations receive equal weights because facility capacity, quality and user preferences are not established.

Let V_j(r) be the vegetation percentage around destination j at radius r. Radii of 100, 300 and 500 m are evaluated with vegetation thresholds g = 10%, 20% and 30%. The joint count is J_i(τ,r,g) = Σ_j 1[t_ij ≤ τ and V_j(r) ≥ g]. Separately, the Pareto set among time-eligible destinations minimises t_ij and maximises V_j(r). A destination is dominated when another is no worse in both criteria and strictly better in at least one, using numerical tolerance 10^−9 in the respective indicator units. The vegetation threshold does not define this Pareto set; it defines the separate joint count.

The full grid contains 20 origins × 3 activity categories × 3 radii × 3 time thresholds × 3 vegetation thresholds = 1,620 parameter rows. Radius sensitivity compares Pareto membership at 100 and 500 m for nineteen routable origins and three time thresholds, giving 57 comparisons per activity. Empty sets are retained. A supplementary precision analysis rounds vegetation alone to 0.001 or 1 percentage point and compares 513 unique origin–activity–radius–time cases. This is numerical sensitivity, not a measured uncertainty model for WorldCover. Water is reported descriptively around eligible destinations; an average of buffer percentages is not the area of their spatial union.

### 3.3 Historical outing scenarios

Each routed pair is evaluated for departures at 08:00, 14:00 and 18:00 on every date in 2021 in the Europe/Sarajevo time zone. Conversion to UTC accounts for daylight saving time. The primary assumed stay is d = 30 minutes, with 15 and 60 minutes retained as duration scenarios. Return travel is assumed to take the same time as outward travel; no independent reverse route is calculated. Total outing duration is T_ij = 2t_ij + d.

For pollutant p, the concentration–time integral is E_p(i,j,s,d) = ∫₀^T_ij C_p(s+u) du, where s is the departure time and C_p is the shared regional concentration in µg/m³. Integration time is measured in minutes, giving µg·min/m³. Each hourly concentration is held constant from its labelled timestamp to the next hour, with fractional hours integrated explicitly. This is a declared temporal discretisation. The same regional concentration applies during travel and the stay, including destinations whose indoor conditions are unknown.

The four pollutants remain separate. E is not inhaled dose: ventilation, individual physiology, indoor infiltration and local spatial variation are not modelled. Complete paired triplets are required for comparison; missing hours would invalidate the case rather than becoming zero. Values outside the archive are not extrapolated. For each pollutant and stay duration, 228 pairs × 365 dates define 83,220 paired cases. They reuse the same environmental series and are not independent measurements or participants. All routed pairs receive equal weight.

Meteorology accompanies the 1,095 date–departure combinations without modifying concentration or the destination ranking. Temperature, relative humidity and wind describe their timestamp; precipitation and shortwave radiation describe the preceding-hour accumulation or mean according to the API documentation. Wind direction denotes where the wind comes from. Directional summaries use eight sectors, speed intervals [0.5,2), [2,4) and ≥4 m/s, and a separate calm category below 0.5 m/s. Concentration summaries require at least ten hours in a bin. These summaries describe co-occurrence, not emission attribution or simulated urban airflow.

### 3.4 Controls and reproducibility

A shared non-negative concentration series imposes a useful control. For the same departure and stay, longer outings occupy nested integration intervals. Their integrals cannot be lower merely because the destination is greener. The implementation checks 4 pollutants × 365 dates × 3 departures = 4,380 nested-interval cases. Additional controls cover a known constant integral, genuine zero concentration, missing values, partial hours and archive boundaries.

Computational verification checks all eighty origin–activity records, all 1,620 parameter rows and an independently implemented PM2.5 integration across the routed pairs and dates. Ten core analytical outputs are regenerated twice offline and compared by SHA-256; the timestamped generation manifest is excluded from byte comparison. The supplementary precision calculation has its own reproduction record. The computation uses Node.js standard-library code with no additional npm dependencies. From the project root, the entry points are `node tools/science-v025.cjs`, `node tests/science-v025.test.cjs` and `node tools/precision-sensitivity-v025.cjs`. Outputs reside in `data/processed/science/v025/`; verification records reside in `review/v025/`. Acquisition is separate from offline recomputation.


### 3.5 Planning interpretation and representation audit

Each indicator is interpreted through four fields: its measured or modelled construct, the planning question it can inform, a permissible preliminary action and the evidence missing before a stronger decision. This interpretive framework is an explicit analytical proposal, not a tested decision-making benefit. Health is the motivation for examining activity-supporting environments; no participants, activity minutes or health outcomes are observed. Satellite classification and regional environmental model output are secondary data, while graph distances and opportunity counts are derived calculations. The station audit is documentary evidence, not an additional measured series in the experiments.

A post-baseline audit tests representation sensitivity without collecting new data. First, the saved directed graph is independently rerouted and compared with all exported distances. Second, all its directional restrictions are removed while holding nodes, geometric segments, segment lengths, way inclusion, snapping and candidates fixed. This isolates a directionality scenario, not a corrected pedestrian network: OSM documents vehicle oneway restrictions separately from pedestrian directionality, but the scenario does not verify every local foot restriction (OpenStreetMap contributors, n.d.). Third, the two unresolved close candidate pairs are grouped as one opportunity per pair. For 19 routable origins and 10/20/30-minute thresholds, unique eligible groups are counted instead of separate records. This does not resolve the pairs' real identity. These checks were added after the main experiments in response to review; they do not constitute a preregistered protocol.

The audit retains both origin and destination connector lengths and their share of total modelled distance. It neither tests obstacle-free passage through those connectors nor repairs topology. The original graph merges nodes by rounded coordinates, so erroneous connections across distinct ways remain a separate unresolved possibility. Results and figures from the original experiments remain explicitly baseline outputs. The baseline Pareto and temporal experiments have not been recomputed for either graph symmetrisation or candidate grouping; the grouping audit separately evaluates cumulative opportunity counts. The audit entry point is `node tools/planning-audit-v027.cjs`.

## 4. FINDINGS

### 4.1 Network proximity changes the nearest destination

Table 2. Nearest-destination changes under network rather than straight-line distance

| Activity | Destinations | Routable origins | Changed nearest set | Maximum additional time to a straight-line nearest destination (min) |
|---|---:|---:|---:|---:|
| All activities, descriptive | 12 | 19/20 | 5/19 | 6.67 |
| Playground | 8 | 19/20 | 4/19 | 5.02 |
| Sports centre | 3 | 19/20 | 3/19 | 9.98 |
| Sports pitch | 1 | 19/20 | 0/19 | 0.00 |

Table 2 shows that a map-distance choice can incur additional modelled walking time. The within-category results are the meaningful comparisons for a specified activity. The mixed-category count is descriptive, while the pitch result follows from having only one candidate and does not demonstrate robustness among alternatives. The maximum differences describe this fixed synthetic origin set, not the distribution of travel burdens among residents.

![Figure 2](figures/v026/figure2-network-choice.png)

Figure 2. Additional modelled walking time incurred by choosing a straight-line nearest destination rather than the network nearest of the same activity. All twenty synthetic origins are displayed; one lacks routes. Tied straight-line minima use the least costly network option. Zero is shown as a dot. These results are conditional on the baseline directionality, snapping and 1.2 m/s walking-speed assumptions.

### 4.2 Vegetation scale changes some compromise sets

Figure 1 places one stated screening scenario in its mapped context. It combines the baseline joint count with the underlying vegetation and water classes. The point values describe candidate records at synthetic origins; they do not identify underserved populations or confirmed venues. This makes the calculation inspectable in space while retaining its limited support.

Of 1,620 parameter rows, 1,539 have a routable origin and 81 remain unknown. Changing the vegetation radius from 100 to 500 m changes the playground Pareto set in 20 of 57 comparisons. No membership change occurs in the 57 sports-centre comparisons or the 57 single-pitch comparisons. These counts include empty sets and describe the tested thresholds and facilities only.

Rounding vegetation to 0.001 percentage point changes 3 of 513 unique Pareto sets relative to the full-precision calculation. Rounding to 1 percentage point changes 17 of 513. All changes occur in the playground category. Under the coarser rounding, the playground radius-sensitivity result becomes 19/57 rather than 20/57. The broad finding therefore persists, although individual front membership can depend on small numerical differences. It would be misleading to present every such difference as environmentally meaningful.

![Figure 3](figures/v026/figure3-radius-sensitivity.png)

Figure 3. Change in the playground Pareto set when the vegetation buffer increases from 100 to 500 m, for each origin and one-way time threshold. Twenty of fifty-seven valid comparisons change; missing-origin cases are excluded from the denominator. Equal sets include empty sets. Pareto criteria are travel time and vegetation percentage, before a separate vegetation-threshold filter.

### 4.3 Departure-time comparisons differ between pollutants

All 83,220 paired cases per pollutant and duration have complete environmental coverage. Table 3 reports the primary thirty-minute-stay scenario. The paired difference is calculated within the same date and origin–destination pair before aggregation. Strict minimum percentages include all 83,220 cases in the denominator, with tied minima counted separately.

Table 3. Shared regional concentration–time comparisons for a thirty-minute stay

| Pollutant | Median E14:00 − E08:00 (µg·min/m³) | Cases with a strict minimum at 14:00 (%) | Tied minima (count) |
|---|---:|---:|---:|
| PM2.5 | −401.35 | 72.86 | 72 |
| PM10 | −224.75 | 44.75 | 24 |
| NO2 | −439.57 | 78.44 | 120 |
| O3 | 2,389.75 | 0.55 | 347 |

The negative median differences for particulate matter and NO2 contrast with the positive ozone difference. Thus, the tested regional histories do not identify a universally preferable departure across pollutants. These comparisons are retrospective and do not recommend 14:00 for a present-day outing. They also do not demonstrate that one street is cleaner than another.

All six acquired meteorological variables contain 8,760 valid UTC hours. Local-calendar monthly and hourly summaries contain 8,759 hours because the UTC-year extract lacks local midnight at the start of 1 January 2021 and includes one hour belonging to 1 January 2022. The latter is excluded from local-year summaries. This boundary issue does not remove any of the selected departure scenarios or their required outing intervals. The wind categories form an exact partition of the 8,760 UTC hours. Meteorology remains contextual; no causal wind–pollution effect or thermal-comfort score is estimated.

![Figure 4](figures/v026/figure4-departure-differences.png)

Figure 4. Paired concentration–time differences between local departure times for a thirty-minute stay and assumed symmetric return. Points show medians; segments span the 10th–90th percentiles of 83,220 date–route scenarios per pollutant. Segments are descriptive ranges, not confidence intervals. Negative values mean a smaller integral at the first labelled time. A common numerical scale does not equate health effects between pollutants. All cases share the regional 2021 series; they are not independent observations or current recommendations.

### 4.4 Evidence controls delimit interpretation

The 4,380 nested-interval checks produce no monotonicity violations. This confirms the computational consequence of shared non-negative concentration under the stated duration assumptions. It is not an empirical discovery that longer walks are harmful, and it does not compare the health benefits of physical activity with pollution risks.

Independent numerical checks and the ten-output offline replay pass. The station audit establishes that official Ilidža hourly displays and reports exist (Federal Hydrometeorological Institute [FHMZ], 2022, n.d.-a), but does not establish a matched, authorised hourly archive for validating the 2021 regional series. Official automatic observations may be unvalidated (FHMZ, n.d.-b). Station-coordinate provenance and reuse terms remain unresolved. No station error statistic, local interpolation or independent validation claim is therefore reported.

### 4.5 Sensitivity of the planning representation

Independent rerouting reproduces all baseline distances without mismatch. Removing graph directionality shortens 125 of 228 routed pairs, with a maximum reduction of 11.45 assumed walking minutes. The nearest sports-centre candidate changes for one of nineteen routable origins; the straight-line versus network disagreement becomes 2/19 rather than the baseline 3/19. The nearest playground set is unchanged by this scenario, retaining 4/19 disagreement with straight-line proximity. Stability of this nearest set does not establish stability of travel times, threshold counts, Pareto sets or temporal integrals.

Both connectors together account for a median 2.13% and maximum 13.94% of total baseline distance across the 228 pairs. Origin connectors range from 9.6 to 138.3 m and destination connectors from 6.0 to 38.2 m. All twenty origins satisfy the 350 m snapping rule; the origin without routes is therefore not explained by exceeding that threshold. Reducing the threshold would change which origins pass the connector check: 17 pass at 50 m and 19 at 100 m. These counts concern snapping only, not complete route availability.

Grouping both unresolved close playground pairs changes the count of opportunities in 15 of 57 origin–time-threshold cases, reducing it by at most two. This is a sensitivity scenario, not a claim that duplicates have been confirmed. For planning interpretation, it demonstrates why a record count should not be presented as an established inventory of independent activity venues.

## 5. DISCUSSION

### 5.1 From indicators to planning questions

The pilot's practical role is to make early questions more specific. It can identify a discrepancy to examine, expose a trade-off and show which missing property prevents a stronger inference. This is relevant at the stage of preparing a brief, reviewing a mapped inventory or comparing assumptions. It does not replace site knowledge, public participation or the statutory planning process. Table 4 translates the outputs into proposed uses; these are interpretations of the evidence, not observed decisions made by study participants.

Table 4. Intended use of indicators in planning, urban design and recreation

| Indicator or evidence | Concrete question | Permissible preliminary use | What it does not establish |
|---|---|---|---|
| Network versus straight-line choice; directional and connector sensitivity | Is an apparent detour due to the city layout or the representation? | Planner or urban designer reviews candidate connections, crossings and entrances in available maps and records | A missing crossing, an actual barrier or a justified construction project |
| Opportunity counts by activity and time; unresolved grouping | How many distinct candidate records remain within this scenario? | Recreation or physical-education coordinator prepares a shortlist for documentary review | Capacity, teaching suitability, permission, universal access or demand |
| Vegetation share and radius-dependent Pareto membership | Is the comparison driven by the immediate setting or the broader neighbourhood? | Landscape or public-space designer examines the spatial context and sensitivity of alternatives | Shade, usable green area, cooling, design quality or a planting benefit |
| Water percentage around a candidate | Does the mapped setting include water that warrants further contextual examination? | Inspect proximity and relation to public space | Water access, safety, quality, amenity or a health bonus |
| Pollutant-specific historical integral and meteorological context | Does the historical timing comparison change between pollutants? | Discuss why venue and programme planning need temporal context and pollutant-specific information | A safe time today, a cleaner parallel route or a prescribed exercise duration |
| Access documentation and unresolved source properties | Which missing fact could invalidate the shortlist? | Assign a focused documentary verification task | Confirmation of access merely because an object is mapped |

For example, the baseline maximum 9.98-minute difference for sports centres could initially suggest inspecting the apparent detour. The directionality audit demonstrates that at least some comparisons change when graph assumptions change. The appropriate first action is therefore to inspect the representation before proposing a physical connection. This is a useful planning result because it can prevent a calculation artefact from becoming a design premise; this potential benefit has not itself been measured.

For playgrounds, the 100–500 m radius comparison addresses a different question. It shows whether the set of travel-time–vegetation compromises depends on a local or wider environmental definition. A larger buffer can include land outside the venue and outside public use. The 20/57 change is thus a reason to make the spatial definition explicit in a design brief, not evidence that one site is healthier. The numerical rounding sensitivity further cautions against interpreting tiny differences as design significance.

### 5.2 Relevance to sport, physical education and health

Urban planning concerns the distribution and connection of potential activity settings; urban design concerns the quality and continuity of the route and place; sport and physical-education practice concerns whether a specific activity can be organised for a particular group. SportSpace contributes preliminary spatial information to this shared problem. It does not equate a playground, a pitch and a sports centre or assume that any mapped candidate is suitable for a class, training session or rehabilitation programme.

The proposed use for physical education is a structured conversation about possible settings: which candidate locations should be checked, which require more travel in the model, and which missing details matter before organising activity? Equipment, group size, supervision, surface condition, toilets, opening hours and permissions remain outside the analysed data. These are conditions for applying a shortlist, not new measurements required to report the present computational case study. They can guide a later extension using existing records where available.

The relation to health is upstream and conditional. A connected and appropriate setting may offer an opportunity for activity, but opportunity does not establish participation, intensity, duration or benefit. The model neither observes these intermediate steps nor estimates their causal relationships. It also cannot balance exercise benefits against pollution risks. The shared historical air series demonstrates that temporal considerations can conflict across pollutants. It should inform the structure of the inquiry, not a recommendation to avoid activity or to exercise at a particular hour.

### 5.3 Validity, limits and reproducibility

The main limitation is the distance between modelled opportunity and real use. Synthetic origins do not represent population, schools, deprivation or activity demand. The technical window can omit alternatives. Candidate identities and access remain incompletely verified, and categories do not provide functional capacity. Directed-edge rules, coordinate-based topology and straight-line connectors constrain the walking interpretation. The new audit quantifies selected sensitivities, but is not a complete pedestrian-model correction. Baseline figures remain valid illustrations of their stated assumptions; they should not be read as a final diagnosis of local walkability.

Environmental support imposes further limits. The network snapshot and 2021 land-cover and hourly histories describe a mixed-year scenario. Satellite vegetation does not establish shade or available green space, and water geometry does not establish use or cooling. Regional air and meteorology cannot differentiate nearby paths or building-scale airflow. The same concentration is assigned during travel and the stay, including potentially indoor facilities. The exact lineage and assimilation status of the saved air archive remain unresolved; no independent station validation is claimed.

Computational reproducibility, interpretive plausibility and real-world validity are separate. Tests and hashes establish what was calculated. Literature explains why the constructs are relevant to planning and health. Neither confirms that an intervention is warranted or that the interface improves decisions. This paper offers a bounded screening method and an account of where its results become sensitive, rather than a completed investment ranking or a health-impact assessment.

Future work can remain focused on the existing-data boundary: checking pedestrian semantics and graph topology against source records, resolving close candidate identities, obtaining documented venue properties and matching authorised station archives if available. An independently designed evaluation could later examine decision usefulness. These steps are not presented as completed evidence and do not require expanding this paper into CFD, new field campaigns or clinical research.

The analytical package stores source identifiers, hashes, assumptions and generated outputs. Dataset-specific attribution and reuse conditions remain attached to their products. A versioned submission archive accompanies the manuscript and contains the analysis scripts, recorded outputs, figures and manifests used in this study. The project repository is https://github.com/3esign/sportspace-pilot/.

## 6. CONCLUSION

SportSpace connects spatial calculations with questions relevant to planning active urban environments. The pilot shows that network representation, the scale of vegetation context and the time of an assumed outing can alter comparisons among mapped recreation candidates. Additional audits show that directionality and unresolved candidate identity also affect results. These are findings about the conditions and limits of preliminary planning evidence.

The method can organise the examination of access, setting and timing for sport and recreation, including the initial review of candidate settings for physical education. It cannot establish venue suitability, participation, equitable provision or health effects. Its defensible contribution is to make the link from an indicator to a planning question and the next necessary evidence explicit, before a map-based result is used as a design or programme decision.

## REFERENCES

Federal Hydrometeorological Institute. (2022). *Godišnji izvještaj o kvalitetu zraka u Federaciji Bosne i Hercegovine za 2021. godinu*. https://www.fhmzbih.gov.ba/PUBLIKACIJE/zrak/izvjestaj-2021.pdf

Federal Hydrometeorological Institute. (n.d.-a). *Ilidža*. Retrieved September 20, 2026, from https://www.fhmzbih.gov.ba/latinica/ZRAK/amsIlidza.php

Federal Hydrometeorological Institute. (n.d.-b). *Metodologija indeksa kvaliteta zraka*. https://www.fhmzbih.gov.ba/latinica/ZRAK/AQI-metodologija.php

Geurs, K. T., & van Wee, B. (2004). Accessibility evaluation of land-use and transport strategies: Review and research directions. *Journal of Transport Geography, 12*(2), 127–140. https://doi.org/10.1016/j.jtrangeo.2003.10.005

Munzner, T. (2009). A nested model for visualization design and validation. *IEEE Transactions on Visualization and Computer Graphics, 15*(6), 921–928. https://www.cs.ubc.ca/labs/imager/tr/2009/NestedModel/

OpenStreetMap contributors. (n.d.). *Key:oneway*. Retrieved September 20, 2026, from https://wiki.openstreetmap.org/wiki/Key:oneway

Open-Meteo. (n.d.-a). *Air quality API*. https://open-meteo.com/en/docs/air-quality-api

Open-Meteo. (n.d.-b). *Historical weather API*. https://open-meteo.com/en/docs/historical-weather-api

Venter, Z., Hassani, A., Stange, E., Schneider, P., & Castell, N. (2024). Reassessing the role of urban green space in air pollution control. *Proceedings of the National Academy of Sciences, 121*, Article e2306200121. https://doi.org/10.1073/pnas.2306200121

World Health Organization. (2018). *Global action plan on physical activity 2018–2030: More active people for a healthier world*. https://www.who.int/publications/i/item/9789241514187

World Health Organization. (2020). *Integrating health in urban and territorial planning: A sourcebook*. https://www.who.int/publications/i/item/9789240003170

World Health Organization Regional Office for Europe. (2016). *Urban green spaces and health*. https://www.who.int/europe/publications/i/item/WHO-EURO-2016-3352-43111-60341

Yan, S., Zhu, S., Fernandez, J. B., Arazo Sánchez, E., Gu, Y., O’Connor, N. E., O’Connor, D., & Liu, M. (2024). *Breathing green: Maximising health and environmental benefits for active transportation users leveraging large scale air quality data* (Version 4) [Preprint]. arXiv. https://doi.org/10.48550/arXiv.2307.15401

Zanaga, D., Van De Kerchove, R., Daems, D., De Keersmaecker, W., Brockmann, C., Kirches, G., Wevers, J., Cartus, O., Santoro, M., Fritz, S., Lesiv, M., Herold, M., Tsendbazar, N. E., Xu, P., Ramoino, F., & Arino, O. (2022). *ESA WorldCover 10 m 2021 v200* [Data set]. Zenodo. https://doi.org/10.5281/zenodo.7254221

