from __future__ import annotations

import copy
import hashlib
import os
import re
import shutil
import tempfile
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Inches, Pt, RGBColor


ROOT = Path(r"C:\Svemir\!Projekti\SportSpace")
SOURCE = ROOT / "paper" / "MANUSCRIPT_ICSIE_26.md"
FINAL_MD = ROOT / "paper" / "MANUSCRIPT_ICSIE_FINAL.md"
TEMPLATE = ROOT / "paper" / "templates" / "ICSIE-2026-official.docx"
OUTPUT = ROOT / "paper" / "SportSpace_ICSIE_2026_FINAL.docx"

FIGURE_RE = re.compile(r"^!\[([^]]*)\]\(([^)]+)\)$")
HEADING_RE = re.compile(r"^(#{1,3})\s+(.+)$")


def clean_source(text: str) -> str:
    text = text.replace(
        "¹ doc. dr. Semir Poturak, University of Travnik, Faculty of Technical Sciences. "
        "ORCID: https://orcid.org/0009-0004-1537-2074. E-mail: awaiting confirmation of correspondence address.",
        "¹ doc. dr. Semir Poturak, University of Travnik, Faculty of Technical Sciences. "
        "ORCID: https://orcid.org/0009-0004-1537-2074. E-mail: semir.poturak@eftfts.edu.ba.",
    )
    text = text.replace(
        "² prof. dr. Amra Tuzović, University of Travnik, Faculty of Technical Sciences. "
        "ORCID and e-mail: awaiting author details.",
        "² prof. dr. Amra Tuzović, University of Travnik, Faculty of Technical Sciences. "
        "E-mail: amra.tuzovic@eftfts.edu.ba.",
    )
    old = (
        "The analytical package stores source identifiers, hashes, assumptions and generated outputs. "
        "Dataset-specific attribution and reuse conditions remain attached to their products. The repository is "
        "https://github.com/3esign/sportspace-pilot/; the new analytical package is currently local and lacks a "
        "public immutable release. Public reproducibility requires that release before submission. The manuscript's "
        "final pagination and author contact metadata also remain editorial work."
    )
    new = (
        "The analytical package stores source identifiers, hashes, assumptions and generated outputs. "
        "Dataset-specific attribution and reuse conditions remain attached to their products. A versioned submission "
        "archive accompanies the manuscript and contains the analysis scripts, recorded outputs, figures and manifests "
        "used in this study. The project repository is https://github.com/3esign/sportspace-pilot/."
    )
    if old not in text:
        raise RuntimeError("Expected reproducibility paragraph was not found")
    return text.replace(old, new)


def set_font(run, name: str = "Times New Roman", size: float | None = None, bold=None, italic=None):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), name)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    run.font.color.rgb = RGBColor(0, 0, 0)


def configure_style(style, size: float, *, bold=False, align=None, first=0.0, left=0.0,
                    hanging=0.0, before=0.0, after=6.0, keep=False):
    style.font.name = "Times New Roman"
    style._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Times New Roman")
    style._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Times New Roman")
    style._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "Times New Roman")
    style.font.size = Pt(size)
    style.font.bold = bold
    style.font.color.rgb = RGBColor(0, 0, 0)
    pf = style.paragraph_format
    pf.alignment = align
    pf.line_spacing_rule = WD_LINE_SPACING.SINGLE
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    pf.left_indent = Cm(left) if left else None
    if hanging:
        pf.left_indent = Cm(hanging)
        pf.first_line_indent = Cm(-hanging)
    else:
        pf.first_line_indent = Cm(first) if first else None
    pf.keep_with_next = keep


def clear_body(doc: Document):
    body = doc._element.body
    sect = body.sectPr
    for child in list(body):
        if child is not sect:
            body.remove(child)


def add_inline(paragraph, text: str, size: float | None = None):
    # Minimal Markdown inline support needed by this manuscript.
    pieces = re.split(r"(`[^`]+`|\*[^*]+\*)", text)
    for piece in pieces:
        if not piece:
            continue
        italic = piece.startswith("*") and piece.endswith("*")
        code = piece.startswith("`") and piece.endswith("`")
        value = piece[1:-1] if italic or code else piece
        run = paragraph.add_run(value)
        set_font(run, size=size, italic=italic)


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    header = OxmlElement("w:tblHeader")
    header.set(qn("w:val"), "true")
    tr_pr.append(header)


def prevent_row_split(row):
    tr_pr = row._tr.get_or_add_trPr()
    cant = OxmlElement("w:cantSplit")
    tr_pr.append(cant)


def shade_cell(cell, fill: str):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=70, start=80, bottom=70, end=80):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for name, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{name}"))
        if node is None:
            node = OxmlElement(f"w:{name}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_borders(table):
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = qn(f"w:{edge}")
        node = borders.find(tag)
        if node is None:
            node = OxmlElement(f"w:{edge}")
            borders.append(node)
        node.set(qn("w:val"), "single")
        node.set(qn("w:sz"), "4" if edge.startswith("inside") else "6")
        node.set(qn("w:color"), "A6A6A6")


def remove_paragraph_borders(paragraph_or_style):
    p_pr = paragraph_or_style._element.get_or_add_pPr()
    borders = p_pr.find(qn("w:pBdr"))
    if borders is not None:
        p_pr.remove(borders)


def add_table(doc: Document, rows: list[list[str]], table_index: int):
    cols = len(rows[0])
    table = doc.add_table(rows=1, cols=cols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    set_table_borders(table)
    size = 9.2 if cols <= 3 else (8.4 if table_index != 4 else 8.0)
    weights = []
    for col in range(cols):
        longest = max(len(r[col]) if col < len(r) else 0 for r in rows)
        weights.append(max(7, min(longest, 32)))
    total = sum(weights)
    usable = 6.28
    widths = [usable * w / total for w in weights]
    for ridx, values in enumerate(rows):
        row = table.rows[0] if ridx == 0 else table.add_row()
        prevent_row_split(row)
        if ridx == 0:
            set_repeat_table_header(row)
        for cidx, value in enumerate(values):
            cell = row.cells[cidx]
            cell.width = Inches(widths[cidx])
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)
            if ridx == 0:
                shade_cell(cell, "E7E6E6")
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if ridx == 0 or cidx > 0 else WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.first_line_indent = None
            p.paragraph_format.left_indent = None
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
            p.paragraph_format.keep_together = True
            add_inline(p, value, size=size)
            for run in p.runs:
                run.bold = ridx == 0


def replace_footnotes(path: Path):
    replacements = {
        "1": (
            " Doc. Dr. Semir Poturak, University of Travnik, Faculty of Technical Sciences. "
            "ORCID: https://orcid.org/0009-0004-1537-2074. E-mail: semir.poturak@eftfts.edu.ba."
        ),
        "2": (
            " Prof. Dr. Amra Tuzović, University of Travnik, Faculty of Technical Sciences. "
            "E-mail: amra.tuzovic@eftfts.edu.ba."
        ),
    }
    with ZipFile(path, "r") as zin:
        entries = {info.filename: zin.read(info.filename) for info in zin.infolist()}
    from lxml import etree
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    root = etree.fromstring(entries["word/footnotes.xml"])
    for fn in root.xpath("//w:footnote", namespaces=ns):
        fid = fn.get(qn("w:id"))
        if fid not in replacements:
            continue
        texts = fn.xpath(".//w:t", namespaces=ns)
        if not texts:
            raise RuntimeError(f"Footnote {fid} has no text node")
        texts[0].text = replacements[fid]
        for node in texts[1:]:
            node.text = ""
    entries["word/footnotes.xml"] = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone="yes")
    temp = path.with_suffix(".tmp.docx")
    with ZipFile(temp, "w", ZIP_DEFLATED) as zout:
        for name, data in entries.items():
            zout.writestr(name, data)
    temp.replace(path)


def build_docx(markdown: str):
    source_doc = Document(str(TEMPLATE))
    author_xml = copy.deepcopy(source_doc.paragraphs[9]._p)
    text_nodes = author_xml.xpath(".//w:t")
    text_nodes[0].text = "Semir POTURAK"
    text_nodes[1].text = ""
    text_nodes[2].text = " and Amra TUZOVIĆ"
    clear_body(source_doc)

    section = source_doc.sections[0]
    section.page_width = Cm(21.0)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2.5)
    section.bottom_margin = Cm(2.5)
    section.left_margin = Cm(2.5)
    section.right_margin = Cm(2.5)
    section.header_distance = Cm(1.25)
    section.footer_distance = Cm(1.25)

    styles = source_doc.styles
    configure_style(styles["Normal"], 12, align=WD_ALIGN_PARAGRAPH.JUSTIFY, first=0.75, after=6)
    configure_style(styles["Title"], 14, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, after=8, keep=True)
    configure_style(styles["Heading 1"], 12, bold=True, align=WD_ALIGN_PARAGRAPH.LEFT, before=10, after=5, keep=True)
    configure_style(styles["Heading 2"], 12, bold=True, align=WD_ALIGN_PARAGRAPH.LEFT, before=7, after=3, keep=True)
    configure_style(styles["Heading 3"], 12, bold=True, align=WD_ALIGN_PARAGRAPH.LEFT, before=5, after=3, keep=True)
    configure_style(styles["Caption"], 11, align=WD_ALIGN_PARAGRAPH.JUSTIFY, after=6, keep=False)
    remove_paragraph_borders(styles["Title"])
    for footnote_style in ("Footnote Text", "Dipnot Metni"):
        try:
            configure_style(styles[footnote_style], 9, align=WD_ALIGN_PARAGRAPH.LEFT, after=0)
            break
        except KeyError:
            continue

    props = source_doc.core_properties
    props.title = "SportSpace Spatial Evidence for Planning Active Urban Environments in Ilidža–Stup"
    props.subject = "ICSIE 2026 full paper"
    props.author = "Semir Poturak; Amra Tuzović"
    props.keywords = "active recreation; environmental context; spatial accessibility; urban design; urban planning"
    props.comments = "Prepared from the official ICSIE 2026 full-paper template."

    lines = markdown.splitlines()
    title = lines[0].removeprefix("# ").strip()
    title_p = source_doc.add_paragraph(style="Title")
    title_run = title_p.add_run(title)
    set_font(title_run, size=14, bold=True)
    remove_paragraph_borders(title_p)
    source_doc._element.body.insert(1, author_xml)

    # Skip markdown title, author line and two author metadata paragraphs.
    i = 8
    in_references = False
    table_index = 0
    last_shape = None
    while i < len(lines):
        raw = lines[i].rstrip()
        line = raw.strip()
        if not line:
            i += 1
            continue

        heading = HEADING_RE.match(line)
        if heading:
            level = len(heading.group(1))
            text = heading.group(2).strip()
            if text == "ABSTRACT":
                p = source_doc.add_paragraph(style="Heading 1")
                p.paragraph_format.space_before = Pt(8)
                p.paragraph_format.space_after = Pt(3)
                add_inline(p, "ABSTRACT", 12)
                p.runs[0].bold = True
            elif text == "REFERENCES":
                p = source_doc.add_paragraph(style="Heading 1")
                add_inline(p, "REFERENCES", 12)
                p.runs[0].bold = True
                in_references = True
            else:
                style = "Heading 1" if level == 2 else ("Heading 2" if level == 3 else "Heading 3")
                p = source_doc.add_paragraph(style=style)
                add_inline(p, text, 12)
                for run in p.runs:
                    run.bold = True
            i += 1
            continue

        if line.startswith("Keywords:"):
            p = source_doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.first_line_indent = None
            p.paragraph_format.space_after = Pt(8)
            label = p.add_run("Keywords: ")
            set_font(label, size=11, bold=True)
            add_inline(p, line[len("Keywords:"):].strip(), 11)
            i += 1
            continue

        figure = FIGURE_RE.match(line)
        if figure:
            image_path = (SOURCE.parent / figure.group(2)).resolve()
            p = source_doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.first_line_indent = None
            p.paragraph_format.space_before = Pt(4)
            p.paragraph_format.space_after = Pt(2)
            p.paragraph_format.keep_with_next = True
            if "figure5" in image_path.name:
                figure_width = 6.05
            elif "figure2" in image_path.name:
                figure_width = 5.55
            else:
                figure_width = 5.80
            width = Inches(figure_width)
            run = p.add_run()
            last_shape = run.add_picture(str(image_path), width=width)
            i += 1
            continue

        if line.startswith("Figure "):
            p = source_doc.add_paragraph(style="Caption")
            p.paragraph_format.keep_together = True
            add_inline(p, line, 10.5)
            if last_shape is not None:
                doc_pr = last_shape._inline.docPr
                doc_pr.set("title", line.split(".", 1)[0])
                doc_pr.set("descr", line)
            last_shape = None
            i += 1
            continue

        if line.startswith("Table ") and i + 2 < len(lines) and lines[i + 2].lstrip().startswith("|"):
            cap = source_doc.add_paragraph(style="Caption")
            cap.alignment = WD_ALIGN_PARAGRAPH.LEFT
            cap.paragraph_format.keep_with_next = True
            add_inline(cap, line, 11)
            i += 1
            continue

        if line.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                vals = [v.strip() for v in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-{3,}:?", v) for v in vals):
                    rows.append(vals)
                i += 1
            table_index += 1
            add_table(source_doc, rows, table_index)
            continue

        # Join contiguous prose lines; the source normally stores one paragraph per line.
        paragraph_lines = [line]
        i += 1
        while i < len(lines) and lines[i].strip() and not HEADING_RE.match(lines[i].strip()) \
                and not lines[i].strip().startswith(("|", "![", "Figure ", "Table ", "Keywords:")):
            paragraph_lines.append(lines[i].strip())
            i += 1
        text = " ".join(paragraph_lines)
        if in_references:
            p = source_doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(1.25)
            p.paragraph_format.first_line_indent = Cm(-1.25)
            p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
            p.paragraph_format.space_after = Pt(3)
            add_inline(p, text, 10.5)
        elif source_doc.paragraphs[-1].text == "ABSTRACT":
            p = source_doc.add_paragraph()
            p.paragraph_format.first_line_indent = None
            p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
            p.paragraph_format.space_after = Pt(5)
            add_inline(p, text, 11)
        else:
            p = source_doc.add_paragraph()
            add_inline(p, text, 12)

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    source_doc.save(str(OUTPUT))
    replace_footnotes(OUTPUT)


def main():
    raw = SOURCE.read_text(encoding="utf-8")
    final = clean_source(raw)
    FINAL_MD.write_text(final, encoding="utf-8", newline="\n")
    build_docx(final)
    print(f"Wrote {FINAL_MD}")
    print(f"Wrote {OUTPUT}")
    print(f"DOCX SHA256 {hashlib.sha256(OUTPUT.read_bytes()).hexdigest()}")


if __name__ == "__main__":
    main()
