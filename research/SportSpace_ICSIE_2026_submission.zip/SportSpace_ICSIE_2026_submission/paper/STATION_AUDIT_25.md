# Stanice — provjera uključivanja u SportSpace

20.09.2026. Status: dokumentarna provjera izvršena; sirova stanična vremenska serija nije integrisana. Čitanje javne stranice nije dokaz licence za redistribuciju baze; odsustvo pronađene licence nije dokaz zabrane korištenja.

| Stavka | Dokaz | Status/posljedica |
|---|---|---|
| Ilidža postoji i objavljuje satne podatke | https://www.fhmzbih.gov.ba/latinica/ZRAK/amsIlidza.php; otvorene tabele14–19.09.2026 | potvrđen javni kratki prozor; nije kontinuirano testirana latencija |
| Automatski podaci nisu validirani | https://www.fhmzbih.gov.ba/latinica/ZRAK/AQI-metodologija.php | satni prikaz odvojiti od validirane historije |
| Izvještaj2021 postoji | https://www.fhmzbih.gov.ba/PUBLIKACIJE/zrak/izvjestaj-2021.pdf,51strana | otvoren primarni tekst, relevantne tabele38/41/44štampana strana; screenshot nije dao upotrebljivu sliku |
| Pokrivenost PM₂.₅ za Ilidžu u izvještaju2021 | tekstualno parsiranje tabele obuhvata na str39 i zbirne tabele26na str44 nije dalo usaglašen jednostavan prepis | ne unositi broj iz neprovjerene tabele kao validirani ulaz; vizuelni pregled i semantika obuhvata ostaju otvoreni |
| Raniji radni izvod Ilidža2024 | data/derived/AIR_PROVENANCE.md, ilidza-air-monthly-2024.csv i ilidza-air-station.geojson | već postoji, nije javni dio pilota; godišnji satni niz nije dostupan u tom izvodu |
| Koordinata stanice | radni izvještaj2024 daje43°49′48.15″/18°18′40.09″; indeksirana službena Strategija ograničenja korištenja uglja2024 daje43°49′40″/18°18′49″ | različiti dokumentarni položaji; ne birati tiho jedan; provjeriti identitet/selidbu/krov naspram druge stanice |
| EEA download servis | https://www.eea.europa.eu/en/datahub/datahubitem-view/778ef9f5-6293-4846-badd-56a29c70880d | servis potvrđen; tačna Ilidža serija/godina nije potvrđena; jedan ArcGIS otvor nije uspio |
| Licenca/API/automatizovano preuzimanje | ciljani upiti FHMZ/ZZJZKS; robots i ZZJZKS kvalitet_zraka nisu otvoreni uspješno ovim alatom | nepoznato; robots ionako ne bi dokazao autorsku licencu |

Strategija: https://mkipgo.ks.gov.ba/sites/mkipgo.ks.gov.ba/files/2024-06/Strategija%20ograni%C4%8Denja%20kori%C5%A1tenja%20uglja.pdf (indeksirana tabela1.1; direktni webopen nije uspio jer dokument ima21.7MB). Radni izvod2024: https://mkipgo.ks.gov.ba/sites/mkipgo.ks.gov.ba/files/2025-07/Izvjestaj%20o%20monitoringu%20kvaliteta%20zraka%20u%20Kantonu%20Sarajevo%20za%202024.%20godnu.pdf.

## Odluka za ovaj rad

E4 završava dokumentarnim auditom, testovima nedostajućih podataka i kontrolom prostorne potpore. Ne izračunavati stanični bias/RMSE iz nepovezanih godina ili godišnje sredine sa nepoznatim validnim satima. Dokumente citirati kao lokalni kontekst, bez preslikavanja cijele baze. Ako se kasnije potvrdi legalno upotrebljiv niz, uskladiti satne intervale i validacione zastavice, pa analizirati samo njihov presjek; prije tvrdnje o nezavisnoj validaciji provjeriti jesu li stanice korištene u asimilaciji modela.

Minimalni budući stanični zapis: station_id,operator,coordinate_source,valid_from/to,pollutant,unit,value,measured_at,published_at,received_at,timezone,aggregation_period,validation_flag,licence_source,raw_hash. Nepoznato je null; ne izmišljati vrijeme objave, granice prostorne reprezentativnosti ili zdravu/sigurnu lokaciju.

Ovo je dokumentovan preostali izvorni problem, ne zahtjev za novim fizičkim mjerenjima. Niko nije kontaktiran; nije pokrenut kolektor ili zakazano praćenje.
