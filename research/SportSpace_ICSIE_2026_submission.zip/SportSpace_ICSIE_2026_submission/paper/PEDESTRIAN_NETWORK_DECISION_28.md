# SportSpace v0.28 — pedestrian-network decision note

Generated: 2026-09-20T02:58:37.496Z

## Decision

For the ICSIE paper, keep the current results as a **baseline screening model** unless a full pedestrian-aware graph variant is generated and all dependent analyses are rerun. Do not silently replace only the visibly sensitive distances.

The reason is methodological, not aesthetic. The v0.27 audit already shows that representation changes are large enough to affect interpretation: removing directional restrictions on the saved geometric graph shortens 125 of 228 routed origin-destination pairs, with a maximum reduction of 11.45 assumed walking minutes. The nearest sports-centre candidate changes for 1 of 19 routable origins under that diagnostic scenario, while the nearest playground set remains stable. Opportunity counts are also sensitive to unresolved close playground records: grouping the two close pairs changes 15 of 57 origin-threshold count cases, with a maximum count reduction of 2.

## What this means for the paper

The paper can defensibly say that SportSpace is a reproducible screening workflow that makes representation uncertainty visible. It should not yet say that it provides a validated pedestrian accessibility diagnosis for Ilidža-Stup. The useful scientific point is that a map-based active-city tool must expose its graph assumptions before its outputs are used for planning, PE coordination or health-related communication.

The strongest current framing is therefore:

- existing data are sufficient for a transparent pilot and methodological contribution;
- network distance, vegetation radius, temporal pollutant scenarios and candidate identity materially shape the planning reading;
- the interface/tool is a decision-support prototype for asking better questions, not a certified decision engine;
- field measurements are a future step, but not required for this bounded paper.

## Rule for a stronger v0.29 result

A new pedestrian-aware run may replace the baseline only if it is created as a separate versioned method run and reruns all downstream products that depend on route time or reachability:

1. graph construction from the same OSM snapshot with pedestrian semantics recorded explicitly;
2. E1 nearest-distance comparisons;
3. E2 cumulative, potential and Pareto calculations;
4. E3 historical concentration-time integrals because travel duration changes exposure duration;
5. Figure 1 analytical map and all manuscript numbers/captions;
6. byte-identical replay, hash manifest and review note.

A partial rerun can be reported only as a diagnostic sensitivity, not as the main result.

## Recommended manuscript stance now

Keep the current manuscript wording cautious. Add only a short clarification if needed: vehicle oneway and roundabout handling is a baseline graph rule; the v0.27 diagnostic shows why future pedestrian-semantics correction is not editorial polish but a scientific dependency. That fits the paper theme: **source -> indicator -> planning question -> permissible preliminary action -> missing evidence**.

## Honest verdict

Verified here: existing v0.27 audit values and their implications for the next methodological decision. Concluded: do not upgrade claims until a full v0.29 rerun exists. Not done here: no new graph was generated, no E1/E2/E3 replacement numbers were produced, and no UI was changed.
