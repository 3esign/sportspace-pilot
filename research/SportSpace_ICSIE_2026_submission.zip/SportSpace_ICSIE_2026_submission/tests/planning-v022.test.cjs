const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),{evaluate}=require('../site/planning.js');
const sandbox={window:{}};vm.runInNewContext(fs.readFileSync(path.join(root,'site/data/sportspace-data.js'),'utf8'),sandbox);const data=sandbox.window.SPORTSPACE_DATA;
const checks=[];
// Independent matrix enumeration across every activity, threshold and removal.
for(const activity of ['all','playground','pitch','sports_centre'])for(const minutes of [5,10,15,20,30,45]){
 const ids=data.candidates.features.filter(f=>activity==='all'||f.properties.activity_class===activity).map(f=>f.properties.feature_id);
 for(const excluded of ['',...ids]){
  const result=evaluate(data,{activity,minutes,excluded});let baseline=0,scenario=0,lost=0;
  for(const f of data.origins.features){let before=0,after=0;for(const r of data.run.rows){if(r.origin_id!==f.properties.origin_id||!ids.includes(r.feature_id)||r.network_distance_m===null||!Number.isFinite(r.travel_time_min)||r.travel_time_min>minutes)continue;before++;if(r.feature_id!==excluded)after++;}baseline+=before>0;scenario+=after>0;lost+=before>0&&after===0;}
  assert.equal(result.baseline,baseline);assert.equal(result.scenario,scenario);assert.equal(result.lost,lost);assert.ok(result.scenario<=result.baseline);assert.equal(result.origins.length,20);
 }
}
checks.push('all activities, 6 thresholds and every candidate exclusion match independent matrix counts');
const fixture={candidates:{features:[{properties:{feature_id:'a',activity_class:'pitch'}}]},origins:{features:[{properties:{origin_id:'edge'}},{properties:{origin_id:'unknown'}}]},run:{rows:[{origin_id:'edge',feature_id:'a',network_distance_m:1080,travel_time_min:15},{origin_id:'unknown',feature_id:'a',network_distance_m:null,travel_time_min:null}]}};
assert.equal(evaluate(fixture,{minutes:15}).baseline,1);assert.equal(evaluate(fixture,{minutes:14.999}).baseline,0);const excluded=evaluate(fixture,{excluded:'a'});assert.equal(excluded.scenario,0);assert.equal(excluded.lost,1);assert.equal(excluded.unrouted,1);assert.equal(excluded.origins[0].scenarioMinutes,null);assert.equal(excluded.origins[1].baselineMinutes,null);checks.push('inclusive threshold, no fake zero, no remaining destination, unknown graph distinct');
assert.throws(()=>evaluate(fixture,{minutes:NaN}));assert.throws(()=>evaluate(fixture,{minutes:-1}));
const report={ok:true,checks,example:evaluate(data,{activity:'playground',minutes:15}).baseline};fs.mkdirSync(path.join(root,'review/v022'),{recursive:true});fs.writeFileSync(path.join(root,'review/v022/calculations.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
