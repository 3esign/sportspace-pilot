# SportSpace — ICSIE 2026 submission archive

This archive accompanies the manuscript *SportSpace: An Existing-Data Urban Planning Pilot for Sport Accessibility, Environmental Context and Time-Sensitive Route Choice*.

## Contents

- `paper/`: final DOCX, editable manuscript, figures, methods/results notes and DOCX build source.
- `data/`: public/licensed environmental inputs and saved scientific outputs.
- `tools/` and `tests/`: reproducible Node/Python analysis and independent checks.
- `software/site-v024/`: self-contained static 2D/3D pilot; open `index.html` in a modern browser.
- `review/`: JSON-only QA records; screenshots are intentionally omitted.

## Reproduce the bounded scientific analysis

From the archive root with Node.js installed:

```text
node tools/science-v025.cjs
node tests/science-v025.test.cjs
node tests/environment-v023.test.cjs
node tests/planning-v022.test.cjs
```

The v0.25 analysis is reconstructable from included OSM-derived browser data, WorldCover clip, CAMS series and ERA5 series. `tools/planning-audit-v027.cjs` is included for inspection, but its private raw-OSM-derived graph inputs are excluded under the project's publication manifest; its saved output and hash trail are included.

## Interpretation boundary

The archive contains a model-based screening study using synthetic origins and mixed-year secondary data. It does not establish health effects, participation, current public access, live air quality, local dispersion, noise exposure or field-validated pedestrian navigation.

Licences and provenance are in `site/DATA-LICENSE.md`, `PUBLICATION_MANIFEST_18.md` and the embedded manifests. No API keys, private correspondence, private raw OSM snapshot or full private walk graph are included.
